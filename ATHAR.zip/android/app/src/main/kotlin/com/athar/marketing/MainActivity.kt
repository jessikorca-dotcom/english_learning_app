package com.athar.marketing

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
