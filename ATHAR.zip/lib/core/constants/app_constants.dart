/// ثوابت عامة يُعاد استخدامها في أكثر من مكان بالتطبيق:

/// أحجام واجهة، مدد زمنية، وقيم افتراضية.

class AppConstants {

  AppConstants._();

  // ============ معلومات التطبيق ============

  static const String companyLogoPath = 'assets/images/logo.png';

  static const String fontFamily = 'Cairo';

  // ============ حدود الإدخال ============

  static const int minPasswordLength = 4;

  static const int maxPasswordLength = 20;

  static const int maxCustomerNameLength = 100;

  static const int maxNotesLength = 1000;

  // ============ مدد زمنية ============

  /// مدة عرض رسائل النجاح/الخطأ (SnackBar) بالمللي ثانية

  static const int snackBarDurationMs = 2500;

  /// عدد الأيام التي يبقى فيها العميل في سلة المحذوفات قبل أن يُقترح

  /// حذفه نهائيًا (لا يُحذف تلقائيًا، فقط يُعرض تنبيه للمدير)

  static const int trashRetentionDays = 30;

  // ============ تنسيقات التاريخ والوقت ============

  static const String dateFormatPattern = 'yyyy/MM/dd';

  static const String timeFormatPattern = 'hh:mm a';

  static const String dateTimeFormatPattern = 'yyyy/MM/dd - hh:mm a';

  // ============ فئات النشاط التجاري الافتراضية ============

  // قائمة جاهزة تُعرض كخيارات سريعة عند إضافة عميل، مع إمكانية إدخال

  // فئة مخصصة يدويًا إن لم تكن ضمن القائمة.

  static const List<String> defaultBusinessCategories = [

    'مطاعم وكافيهات',

    'عيادات وخدمات طبية',

    'تجارة إلكترونية',

    'عقارات',

    'أزياء وموضة',

    'تعليم وتدريب',

    'خدمات مالية',

    'سيارات',

    'صالونات وتجميل',

    'أخرى',

  ];

  // ============ حدود واجهة عامة ============

  static const double defaultPadding = 16.0;

  static const double defaultBorderRadius = 12.0;

  static const double cardElevation = 2.0;

}