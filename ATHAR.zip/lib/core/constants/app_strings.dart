/// ملف يحتوي كل النصوص الثابتة الظاهرة في واجهة التطبيق.

/// تجميع النصوص هنا يسهّل الصيانة ويمنع تكرارها داخل الشاشات المختلفة.

class AppStrings {

  AppStrings._(); // يمنع إنشاء نسخة من هذا الكلاس، فهو يُستخدم فقط كحاوية ثوابت

  // ============ اسم التطبيق ============

  static const String appName = ' Marketing-أثر';

  static const String appNameEnglish = 'ATHAR';

  // ============ شاشة اختيار الدخول ============

  static const String chooseRole = 'اختر طريقة الدخول';

  static const String manager = 'مدير';

  static const String employee = 'موظف';

  // ============ شاشة كلمة مرور المدير ============

  static const String enterPassword = 'أدخل كلمة المرور';

  static const String password = 'كلمة المرور';

  static const String login = 'دخول';

  static const String wrongPassword = 'كلمة المرور غير صحيحة';

  // ============ شاشة الإعداد الأول ============

  static const String firstSetupTitle = 'إعداد كلمة مرور المدير';

  static const String firstSetupSubtitle =

      'هذه الخطوة تتم مرة واحدة فقط عند أول تشغيل للتطبيق';

  static const String createPassword = 'إنشاء كلمة المرور';

  static const String confirmPassword = 'تأكيد كلمة المرور';

  static const String passwordsDoNotMatch = 'كلمتا المرور غير متطابقتين';

  static const String passwordTooShort =

      'يجب ألا تقل كلمة المرور عن 4 أحرف';

  static const String saveAndContinue = 'حفظ ومتابعة';

  // ============ الشاشة الرئيسية ============

  static const String customersList = 'قائمة العملاء';

  static const String noCustomersYet = 'لا يوجد عملاء بعد';

  static const String addFirstCustomer = 'ابدأ بإضافة أول عميل';

  static const String search = 'بحث';

  static const String searchHint = 'ابحث باسم العميل أو النشاط التجاري...';

  // ============ إضافة / تعديل عميل ============

  static const String addCustomer = 'إضافة عميل';

  static const String editCustomer = 'تعديل بيانات العميل';

  static const String customerName = 'اسم العميل';

  static const String businessName = 'اسم النشاط التجاري';

  static const String businessCategory = 'الفئة التجارية';

  static const String marketingProblem = 'المشكلة التسويقية';

  static const String providedService = 'الخدمة المقدمة';

  static const String additionalNotes = 'ملاحظات إضافية';

  static const String employeeName = 'اسم الموظف (اختياري)';

  static const String save = 'حفظ';

  static const String cancel = 'إلغاء';

  static const String requiredField = 'هذا الحقل مطلوب';

  // ============ تفاصيل العميل ============

  static const String customerDetails = 'تفاصيل العميل';

  static const String createdAt = 'تاريخ الإضافة';

  static const String createdTime = 'وقت الإضافة';

  static const String lastModified = 'آخر تعديل';

  static const String customerId = 'رقم العميل';

  static const String copyInfo = 'نسخ البيانات';

  static const String infoCopied = 'تم نسخ البيانات بنجاح';

  static const String exportPdf = 'تصدير PDF';

  static const String edit = 'تعديل';

  static const String delete = 'حذف';

  static const String addToFavorites = 'إضافة للمفضلة';

  static const String removeFromFavorites = 'إزالة من المفضلة';

  // ============ الحذف والاستعادة ============

  static const String confirmDeleteTitle = 'تأكيد الحذف';

  static const String confirmDeleteMessage =

      'سيتم نقل هذا العميل إلى سلة المحذوفات، ويمكنك استعادته لاحقًا';

  static const String deletedSuccessfully = 'تم حذف العميل';

  static const String trash = 'سلة المحذوفات';

  static const String emptyTrash = 'سلة المحذوفات فارغة';

  static const String restore = 'استعادة';

  static const String restoredSuccessfully = 'تم استعادة العميل';

  static const String permanentDeleteWarning =

      'هذا الإجراء نهائي ولا يمكن التراجع عنه';

  // ============ الإحصائيات ============

  static const String statistics = 'الإحصائيات';

  static const String totalCustomers = 'إجمالي العملاء';

  static const String byCategory = 'حسب الفئة التجارية';

  static const String byEmployee = 'حسب الموظف';

  static const String monthlyGrowth = 'النمو الشهري';

  // ============ المفضلة ============

  static const String favorites = 'العملاء المفضلون';

  static const String noFavoritesYet = 'لا يوجد عملاء مفضلون بعد';

  // ============ سجل الأنشطة ============

  static const String activityLog = 'سجل الأنشطة';

  static const String noActivityYet = 'لا يوجد نشاط مسجل بعد';

  static const String activityAdded = 'تمت إضافة عميل جديد';

  static const String activityEdited = 'تم تعديل بيانات عميل';

  static const String activityDeleted = 'تم حذف عميل';

  static const String activityRestored = 'تم استعادة عميل';

  // ============ الإعدادات ============

  static const String settings = 'الإعدادات';

  static const String changePassword = 'تغيير كلمة المرور';

  static const String currentPassword = 'كلمة المرور الحالية';

  static const String newPassword = 'كلمة المرور الجديدة';

  static const String passwordChanged = 'تم تغيير كلمة المرور بنجاح';

  static const String backup = 'نسخة احتياطية';

  static const String exportBackup = 'تصدير نسخة احتياطية';

  static const String importBackup = 'استيراد نسخة احتياطية';

  static const String backupExported = 'تم تصدير النسخة الاحتياطية بنجاح';

  static const String backupImported = 'تم استيراد النسخة بنجاح';

  static const String darkMode = 'الوضع الداكن';

  static const String logout = 'تسجيل الخروج';

  // ============ رسائل عامة ============

  static const String somethingWentWrong = 'حدث خطأ ما، يرجى المحاولة مرة أخرى';

  static const String loading = 'جاري التحميل...';

  static const String yes = 'نعم';

  static const String no = 'لا';

  static const String ok = 'حسنًا';

}