/// أسماء صناديق Hive ومفاتيح التخزين المستخدمة في التطبيق.

/// تجميعها هنا يمنع تكرار كتابة النصوص الحرفية (String literals) في أكثر

/// من مكان، وهو مصدر شائع للأخطاء عند الكتابة اليدوية.

class HiveConstants {

  HiveConstants._();

  // ============ أسماء الصناديق (Boxes) ============

  /// صندوق تخزين بيانات العملاء النشطين (غير المحذوفين)

  static const String customersBox = 'customers_box';

  /// صندوق تخزين العملاء المحذوفين مؤقتًا (سلة المحذوفات)

  static const String deletedCustomersBox = 'deleted_customers_box';

  /// صندوق تخزين سجل الأنشطة

  static const String activityLogBox = 'activity_log_box';

  /// صندوق تخزين إعدادات التطبيق العامة (كلمة مرور المدير، الوضع الداكن...)

  static const String settingsBox = 'settings_box';

  // ============ معرّفات نوع الـ TypeAdapter ============

  // كل نوع بيانات نخزنه في Hive يحتاج رقم فريد (typeId) لا يتكرر أبدًا

  // بين النماذج المختلفة. سيُستخدم هذا الرقم عند كتابة TypeAdapter يدويًا

  // في ملفات النماذج القادمة.

  static const int customerTypeId = 0;

  static const int activityLogTypeId = 1;

  // ============ مفاتيح داخل settingsBox ============

  // settingsBox هو صندوق "عام" يخزن قيمًا منفردة (ليس قائمة كائنات)

  // لذلك نحتاج مفاتيح ثابتة للوصول لكل قيمة بداخله.

  static const String keyManagerPasswordHash = 'manager_password_hash';

  static const String keyManagerPasswordSalt = 'manager_password_salt';

  static const String keyIsFirstRun = 'is_first_run';

  static const String keyIsDarkMode = 'is_dark_mode';

}