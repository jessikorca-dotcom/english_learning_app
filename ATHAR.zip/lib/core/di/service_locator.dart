import '../../repositories/customer_repository.dart';

import '../../repositories/auth_repository.dart';

import '../../repositories/activity_log_repository.dart';

/// نقطة مركزية واحدة تربط كل واجهة Repository مجرّدة بتنفيذها الحالي.

///

/// ==========================================================

/// عند الانتقال للسحابة مستقبلًا (Firebase/Appwrite):

/// 1. أنشئ FirebaseCustomerRepository implements CustomerRepository

/// 2. استبدل السطر customerRepository = HiveCustomerRepository()

///    بـ customerRepository = FirebaseCustomerRepository()

/// 3. لا حاجة لأي تعديل آخر في أي شاشة أو Provider بالتطبيق.

/// ==========================================================

class ServiceLocator {

  ServiceLocator._();

  /// المستودع المسؤول عن كل عمليات العملاء (إضافة، تعديل، حذف، بحث...)

  static final CustomerRepository customerRepository =

      HiveCustomerRepository();

  /// المستودع المسؤول عن المصادقة (كلمة مرور المدير)

  static final AuthRepository authRepository = LocalAuthRepository();

  /// المستودع المسؤول عن سجل الأنشطة

  static final ActivityLogRepository activityLogRepository =

      HiveActivityLogRepository();

}