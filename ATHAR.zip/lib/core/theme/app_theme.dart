import 'package:flutter/material.dart';

import '../constants/app_constants.dart';

/// يحدد الثيمين الفاتح والداكن للتطبيق.

/// كل الألوان والأنماط مركزية هنا لضمان اتساق المظهر عبر كل الشاشات.

class AppTheme {

  AppTheme._();

  // ============ لوحة الألوان الأساسية ============

  static const Color _primaryNavy = Color(0xFF1B2A4A);

  static const Color _primaryNavyLight = Color(0xFF2E4470);

  static const Color _accentGold = Color(0xFFC9A24B);

  static const Color _dangerRed = Color(0xFFD64545);

  static const Color _successGreen = Color(0xFF3E9B6F);

  static const Color _lightBackground = Color(0xFFF7F7F9);

  static const Color _lightSurface = Color(0xFFFFFFFF);

  static const Color _darkBackground = Color(0xFF10131C);

  static const Color _darkSurface = Color(0xFF1A1E2A);

  // ألوان يمكن الوصول إليها من أي مكان بالتطبيق (مثال: رسائل النجاح/الخطأ)

  static const Color dangerColor = _dangerRed;

  static const Color successColor = _successGreen;

  static const Color accentColor = _accentGold;

  // ============ الثيم الفاتح ============

  static ThemeData get lightTheme {

    return ThemeData(

      useMaterial3: true,

      fontFamily: AppConstants.fontFamily,

      brightness: Brightness.light,

      scaffoldBackgroundColor: _lightBackground,

      colorScheme: const ColorScheme.light(

        primary: _primaryNavy,

        secondary: _accentGold,

        surface: _lightSurface,

        error: _dangerRed,

      ),

      appBarTheme: const AppBarTheme(

        backgroundColor: _primaryNavy,

        foregroundColor: Colors.white,

        elevation: 0,

        centerTitle: true,

        titleTextStyle: TextStyle(

          fontFamily: AppConstants.fontFamily,

          fontSize: 20,

          fontWeight: FontWeight.bold,

          color: Colors.white,

        ),

      ),

      cardTheme: CardThemeData(

        color: _lightSurface,

        elevation: AppConstants.cardElevation,

        shape: RoundedRectangleBorder(

          borderRadius:

              BorderRadius.circular(AppConstants.defaultBorderRadius),

        ),

        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 0),

      ),

      elevatedButtonTheme: ElevatedButtonThemeData(

        style: ElevatedButton.styleFrom(

          backgroundColor: _primaryNavy,

          foregroundColor: Colors.white,

          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),

          shape: RoundedRectangleBorder(

            borderRadius:

                BorderRadius.circular(AppConstants.defaultBorderRadius),

          ),

          textStyle: const TextStyle(

            fontFamily: AppConstants.fontFamily,

            fontSize: 16,

            fontWeight: FontWeight.w600,

          ),

        ),

      ),

      outlinedButtonTheme: OutlinedButtonThemeData(

        style: OutlinedButton.styleFrom(

          foregroundColor: _primaryNavy,

          side: const BorderSide(color: _primaryNavy),

          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),

          shape: RoundedRectangleBorder(

            borderRadius:

                BorderRadius.circular(AppConstants.defaultBorderRadius),

          ),

        ),

      ),

      inputDecorationTheme: InputDecorationTheme(

        filled: true,

        fillColor: _lightSurface,

        contentPadding: const EdgeInsets.symmetric(

          vertical: 14,

          horizontal: 16,

        ),

        border: OutlineInputBorder(

          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),

          borderSide: BorderSide(color: Colors.grey.shade300),

        ),

        enabledBorder: OutlineInputBorder(

          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),

          borderSide: BorderSide(color: Colors.grey.shade300),

        ),

        focusedBorder: OutlineInputBorder(

          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),

          borderSide: const BorderSide(color: _primaryNavy, width: 1.6),

        ),

        errorBorder: OutlineInputBorder(

          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),

          borderSide: const BorderSide(color: _dangerRed),

        ),

        labelStyle: const TextStyle(fontFamily: AppConstants.fontFamily),

        hintStyle: TextStyle(

          fontFamily: AppConstants.fontFamily,

          color: Colors.grey.shade500,

        ),

      ),

      textTheme: _buildTextTheme(Brightness.light),

      floatingActionButtonTheme: const FloatingActionButtonThemeData(

        backgroundColor: _accentGold,

        foregroundColor: _primaryNavy,

      ),

      snackBarTheme: SnackBarThemeData(

        behavior: SnackBarBehavior.floating,

        shape: RoundedRectangleBorder(

          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),

        ),

        contentTextStyle: const TextStyle(fontFamily: AppConstants.fontFamily),

      ),

      dividerTheme: DividerThemeData(color: Colors.grey.shade200, thickness: 1),

    );

  }

  // ============ الثيم الداكن ============

  static ThemeData get darkTheme {

    return ThemeData(

      useMaterial3: true,

      fontFamily: AppConstants.fontFamily,

      brightness: Brightness.dark,

      scaffoldBackgroundColor: _darkBackground,

      colorScheme: const ColorScheme.dark(

        primary: _primaryNavyLight,

        secondary: _accentGold,

        surface: _darkSurface,

        error: _dangerRed,

      ),

      appBarTheme: const AppBarTheme(

        backgroundColor: _darkSurface,

        foregroundColor: Colors.white,

        elevation: 0,

        centerTitle: true,

        titleTextStyle: TextStyle(

          fontFamily: AppConstants.fontFamily,

          fontSize: 20,

          fontWeight: FontWeight.bold,

          color: Colors.white,

        ),

      ),

      cardTheme: CardThemeData(

        color: _darkSurface,

        elevation: AppConstants.cardElevation,

        shape: RoundedRectangleBorder(

          borderRadius:

              BorderRadius.circular(AppConstants.defaultBorderRadius),

        ),

        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 0),

      ),

      elevatedButtonTheme: ElevatedButtonThemeData(

        style: ElevatedButton.styleFrom(

          backgroundColor: _primaryNavyLight,

          foregroundColor: Colors.white,

          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),

          shape: RoundedRectangleBorder(

            borderRadius:

                BorderRadius.circular(AppConstants.defaultBorderRadius),

          ),

          textStyle: const TextStyle(

            fontFamily: AppConstants.fontFamily,

            fontSize: 16,

            fontWeight: FontWeight.w600,

          ),

        ),

      ),

      outlinedButtonTheme: OutlinedButtonThemeData(

        style: OutlinedButton.styleFrom(

          foregroundColor: _accentGold,

          side: const BorderSide(color: _accentGold),

          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),

          shape: RoundedRectangleBorder(

            borderRadius:

                BorderRadius.circular(AppConstants.defaultBorderRadius),

          ),

        ),

      ),

      inputDecorationTheme: InputDecorationTheme(

        filled: true,

        fillColor: _darkSurface,

        contentPadding: const EdgeInsets.symmetric(

          vertical: 14,

          horizontal: 16,

        ),

        border: OutlineInputBorder(

          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),

          borderSide: BorderSide(color: Colors.grey.shade800),

        ),

        enabledBorder: OutlineInputBorder(

          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),

          borderSide: BorderSide(color: Colors.grey.shade800),

        ),

        focusedBorder: OutlineInputBorder(

          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),

          borderSide: const BorderSide(color: _accentGold, width: 1.6),

        ),

        errorBorder: OutlineInputBorder(

          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),

          borderSide: const BorderSide(color: _dangerRed),

        ),

        labelStyle: const TextStyle(fontFamily: AppConstants.fontFamily),

        hintStyle: TextStyle(

          fontFamily: AppConstants.fontFamily,

          color: Colors.grey.shade500,

        ),

      ),

      textTheme: _buildTextTheme(Brightness.dark),

      floatingActionButtonTheme: const FloatingActionButtonThemeData(

        backgroundColor: _accentGold,

        foregroundColor: _primaryNavy,

      ),

      snackBarTheme: SnackBarThemeData(

        behavior: SnackBarBehavior.floating,

        backgroundColor: _darkSurface,

        shape: RoundedRectangleBorder(

          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),

        ),

        contentTextStyle: const TextStyle(fontFamily: AppConstants.fontFamily),

      ),

      dividerTheme: DividerThemeData(color: Colors.grey.shade800, thickness: 1),

    );

  }

  // ============ نص موحّد لكلا الوضعين ============

  static TextTheme _buildTextTheme(Brightness brightness) {

    final Color baseColor =

        brightness == Brightness.dark ? Colors.white : const Color(0xFF1A1A1A);

    return TextTheme(

      headlineMedium: TextStyle(

        fontFamily: AppConstants.fontFamily,

        fontSize: 22,

        fontWeight: FontWeight.bold,

        color: baseColor,

      ),

      titleLarge: TextStyle(

        fontFamily: AppConstants.fontFamily,

        fontSize: 18,

        fontWeight: FontWeight.w700,

        color: baseColor,

      ),

      titleMedium: TextStyle(

        fontFamily: AppConstants.fontFamily,

        fontSize: 16,

        fontWeight: FontWeight.w600,

        color: baseColor,

      ),

      bodyLarge: TextStyle(

        fontFamily: AppConstants.fontFamily,

        fontSize: 15,

        color: baseColor,

      ),

      bodyMedium: TextStyle(

        fontFamily: AppConstants.fontFamily,

        fontSize: 14,

        color: baseColor,

      ),

      bodySmall: TextStyle(

        fontFamily: AppConstants.fontFamily,

        fontSize: 12,

        color: baseColor.withValues(alpha: 0.7),

      ),

    );

  }

}