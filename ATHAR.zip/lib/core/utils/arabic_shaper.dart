/// أداة محلية لإعادة تشكيل الحروف العربية لعرضها بشكل متصل وصحيح

/// داخل مكتبة pdf، والتي لا تحتوي محرك تشكيل حروف مدمجًا.

/// لا تعتمد على أي حزمة خارجية، فقط جداول Unicode القياسية.

class ArabicShaper {

  ArabicShaper._();

  // كل حرف عربي له حتى 4 أشكال: [معزول, نهاية, بداية, وسط]

  // الحروف التي لا تتصل بما بعدها (مثل ا، د، ذ، ر، ز، و، ى) لها شكلان فقط.

  static const Map<String, List<int>> _forms = {

    'ء': [0xFE80],

    'آ': [0xFE81, 0xFE82],

    'أ': [0xFE83, 0xFE84],

    'ؤ': [0xFE85, 0xFE86],

    'إ': [0xFE87, 0xFE88],

    'ئ': [0xFE89, 0xFE8A, 0xFE8B, 0xFE8C],

    'ا': [0xFE8D, 0xFE8E],

    'ب': [0xFE8F, 0xFE90, 0xFE91, 0xFE92],

    'ة': [0xFE93, 0xFE94],

    'ت': [0xFE95, 0xFE96, 0xFE97, 0xFE98],

    'ث': [0xFE99, 0xFE9A, 0xFE9B, 0xFE9C],

    'ج': [0xFE9D, 0xFE9E, 0xFE9F, 0xFEA0],

    'ح': [0xFEA1, 0xFEA2, 0xFEA3, 0xFEA4],

    'خ': [0xFEA5, 0xFEA6, 0xFEA7, 0xFEA8],

    'د': [0xFEA9, 0xFEAA],

    'ذ': [0xFEAB, 0xFEAC],

    'ر': [0xFEAD, 0xFEAE],

    'ز': [0xFEAF, 0xFEB0],

    'س': [0xFEB1, 0xFEB2, 0xFEB3, 0xFEB4],

    'ش': [0xFEB5, 0xFEB6, 0xFEB7, 0xFEB8],

    'ص': [0xFEB9, 0xFEBA, 0xFEBB, 0xFEBC],

    'ض': [0xFEBD, 0xFEBE, 0xFEBF, 0xFEC0],

    'ط': [0xFEC1, 0xFEC2, 0xFEC3, 0xFEC4],

    'ظ': [0xFEC5, 0xFEC6, 0xFEC7, 0xFEC8],

    'ع': [0xFEC9, 0xFECA, 0xFECB, 0xFECC],

    'غ': [0xFECD, 0xFECE, 0xFECF, 0xFED0],

    'ف': [0xFED1, 0xFED2, 0xFED3, 0xFED4],

    'ق': [0xFED5, 0xFED6, 0xFED7, 0xFED8],

    'ك': [0xFED9, 0xFEDA, 0xFEDB, 0xFEDC],

    'ل': [0xFEDD, 0xFEDE, 0xFEDF, 0xFEE0],

    'م': [0xFEE1, 0xFEE2, 0xFEE3, 0xFEE4],

    'ن': [0xFEE5, 0xFEE6, 0xFEE7, 0xFEE8],

    'ه': [0xFEE9, 0xFEEA, 0xFEEB, 0xFEEC],

    'و': [0xFEED, 0xFEEE],

    'ى': [0xFEEF, 0xFEF0],

    'ي': [0xFEF1, 0xFEF2, 0xFEF3, 0xFEF4],

  };

  // الحروف التي لا تتصل بالحرف الذي يليها (شكلان فقط: معزول/نهاية)

  static const Set<String> _nonConnectingForward = {

    'ء', 'آ', 'أ', 'ؤ', 'إ', 'ا', 'ة', 'د', 'ذ', 'ي', 'ز', 'و', 'ى',

  };

  static bool _isArabicLetter(String ch) => _forms.containsKey(ch);

  /// يعيد تشكيل نص عربي بالكامل ليظهر متصلاً وصحيحًا في PDF.

  /// أي حرف غير عربي (أرقام، إنجليزي، رموز، مسافات) يمر كما هو دون تعديل.

  static String reshape(String text) {

    final StringBuffer result = StringBuffer();

    for (int i = 0; i < text.length; i++) {

      final String ch = text[i];

      if (!_isArabicLetter(ch)) {

        result.write(ch);

        continue;

      }

      final String? prev = i > 0 ? text[i - 1] : null;

      final String? next = i < text.length - 1 ? text[i + 1] : null;

      final bool connectsFromPrev = prev != null &&

          _isArabicLetter(prev) &&

          !_nonConnectingForward.contains(prev);

      final bool connectsToNext = next != null &&

          _isArabicLetter(next) &&

          !_nonConnectingForward.contains(ch);

      final List<int> forms = _forms[ch]!;

      final int codePoint;

      if (forms.length == 2) {

        // حرف بشكلين فقط: معزول أو نهاية (حسب الاتصال بما قبله)

        codePoint = connectsFromPrev ? forms[1] : forms[0];

      } else {

        // حرف بأربعة أشكال

        if (connectsFromPrev && connectsToNext) {

          codePoint = forms[3]; // وسط

        } else if (connectsFromPrev) {

          codePoint = forms[1]; // نهاية

        } else if (connectsToNext) {

          codePoint = forms[2]; // بداية

        } else {

          codePoint = forms[0]; // معزول

        }

      }

      result.writeCharCode(codePoint);

    }

    return result.toString();

  }

}