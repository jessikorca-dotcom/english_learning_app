import 'package:flutter/material.dart';

import 'package:flutter/foundation.dart';

import 'package:flutter_localizations/flutter_localizations.dart';

import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';

import 'core/constants/app_strings.dart';

import 'services/hive_service.dart';

import 'providers/auth_provider.dart';

import 'providers/customer_provider.dart';

import 'providers/activity_log_provider.dart';

import 'providers/statistics_provider.dart';

import 'providers/theme_provider.dart';

import 'screens/splash/splash_decider_screen.dart';

Future<void> main() async {

  // ضروري لأننا نستدعي كودًا غير متزامن (Hive) قبل runApp

  WidgetsFlutterBinding.ensureInitialized();

  await HiveService.initialize();

  runApp(const AtharApp());

}

/// الودجت الجذري للتطبيق. يوفّر كل الـ Providers، ويضبط الثيم

/// واللغة والاتجاه، ثم يعرض شاشة البداية التي تقرر الوجهة المناسبة

/// (إعداد أول، دخول، أو الشاشة الرئيسية مباشرة).

class AtharApp extends StatelessWidget {

  const AtharApp({super.key});

  @override

  Widget build(BuildContext context) {

    return MultiProvider(

      providers: [

        ChangeNotifierProvider(create: (_) => AuthProvider()),

        ChangeNotifierProvider(create: (_) => CustomerProvider()),

        ChangeNotifierProvider(create: (_) => ActivityLogProvider()),

        ChangeNotifierProvider(create: (_) => StatisticsProvider()),

        ChangeNotifierProvider(

          create: (_) => ThemeProvider()..loadThemePreference(),

        ),

      ],

      child: Consumer<ThemeProvider>(

        builder: (context, themeProvider, _) {

          return MaterialApp(

            debugShowCheckedModeBanner: false,

            title: AppStrings.appName,

            theme: AppTheme.lightTheme,

            darkTheme: AppTheme.darkTheme,

            themeMode: themeProvider.themeMode,

            // ============ ضبط اللغة العربية بشكل كامل وقسري ============

            locale: const Locale('ar'),

            supportedLocales: const [Locale('ar')],

            localizationsDelegates: const [

              GlobalMaterialLocalizations.delegate,

              GlobalWidgetsLocalizations.delegate,

              GlobalCupertinoLocalizations.delegate,

            ],

            // يضمن اتجاه RTL في كل الشاشات بغض النظر عن أي شيء آخر

            builder: (context, child) {

              return Directionality(

                textDirection: TextDirection.rtl,

                child: child ?? const SizedBox.shrink(),

              );

            },

            home: const SplashDeciderScreen(),

          );

        },

      ),

    );

  }

}