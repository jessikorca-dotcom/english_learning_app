import 'package:hive/hive.dart';

import '../core/constants/hive_constants.dart';

/// أنواع الأنشطة الممكن تسجيلها في النظام.

enum ActivityType {

  added,

  edited,

  deleted,

  restored,

}

/// يمثل سجل نشاط واحد يوثّق عملية تمت على أحد العملاء.

class ActivityLogEntry extends HiveObject {

  /// معرّف فريد للسجل نفسه

  String id;

  /// نوع العملية التي حدثت

  ActivityType type;

  /// معرّف العميل الذي طالته العملية (للربط لاحقًا إن احتجنا)

  String customerId;

  /// اسم العميل وقت حدوث العملية (نخزنه كنص مستقل حتى لو حُذف العميل

  /// لاحقًا نهائيًا، يبقى السجل قابلاً للقراءة بدون كسر الروابط)

  String customerName;

  /// من قام بالعملية: "المدير" أو اسم الموظف إن وُجد

  String performedBy;

  /// تاريخ ووقت حدوث العملية

  final DateTime timestamp;

  ActivityLogEntry({

    required this.id,

    required this.type,

    required this.customerId,

    required this.customerName,

    required this.performedBy,

    required this.timestamp,

  });

}

/// محوّل يدوي لتخزين/قراءة كائنات ActivityLogEntry داخل Hive.

class ActivityLogEntryAdapter extends TypeAdapter<ActivityLogEntry> {

  @override

  final int typeId = HiveConstants.activityLogTypeId;

  @override

  ActivityLogEntry read(BinaryReader reader) {

    final int numOfFields = reader.readByte();

    final Map<int, dynamic> fields = <int, dynamic>{

      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),

    };

    return ActivityLogEntry(

      id: fields[0] as String,

      type: ActivityType.values[fields[1] as int],

      customerId: fields[2] as String,

      customerName: fields[3] as String,

      performedBy: fields[4] as String,

      timestamp: fields[5] as DateTime,

    );

  }

  @override

  void write(BinaryWriter writer, ActivityLogEntry obj) {

    writer

      ..writeByte(6) // عدد الحقول الكلي

      ..writeByte(0)

      ..write(obj.id)

      ..writeByte(1)

      ..write(obj.type.index)

      ..writeByte(2)

      ..write(obj.customerId)

      ..writeByte(3)

      ..write(obj.customerName)

      ..writeByte(4)

      ..write(obj.performedBy)

      ..writeByte(5)

      ..write(obj.timestamp);

  }

}