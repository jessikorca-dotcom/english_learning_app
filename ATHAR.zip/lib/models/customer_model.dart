import 'package:hive/hive.dart';

import '../core/constants/hive_constants.dart';

/// يمثل بيانات عميل واحد داخل النظام.

/// يمتد من HiveObject لتوفير وصول مباشر لعمليات save()/delete() الجاهزة.

class Customer extends HiveObject {

  /// معرّف فريد يُولَّد تلقائيًا عند إنشاء العميل (لا يتغير أبدًا بعد ذلك)

  String id;

  String customerName;

  String businessName;

  String businessCategory;

  String marketingProblem;

  String providedService;

  String additionalNotes;

  /// اسم الموظف الذي أضاف العميل، اختياري

  String? employeeName;

  /// تاريخ ووقت الإنشاء، يُضبط تلقائيًا ولا يُعدَّل يدويًا أبدًا

  final DateTime createdAt;

  /// تاريخ ووقت آخر تعديل، يُحدَّث تلقائيًا عند كل حفظ تعديل

  DateTime lastModified;

  /// هل العميل ضمن المفضلة لدى المدير

  bool isFavorite;

  Customer({

    required this.id,

    required this.customerName,

    required this.businessName,

    required this.businessCategory,

    required this.marketingProblem,

    required this.providedService,

    required this.additionalNotes,

    this.employeeName,

    required this.createdAt,

    required this.lastModified,

    this.isFavorite = false,

  });

  /// ينشئ نسخة معدَّلة من العميل مع تحديث lastModified تلقائيًا.

  /// يُستخدم عند حفظ تعديل بدل تعديل الحقول واحدًا تلو الآخر يدويًا.

  Customer copyWith({

    String? customerName,

    String? businessName,

    String? businessCategory,

    String? marketingProblem,

    String? providedService,

    String? additionalNotes,

    String? employeeName,

    bool? isFavorite,

  }) {

    return Customer(

      id: id,

      customerName: customerName ?? this.customerName,

      businessName: businessName ?? this.businessName,

      businessCategory: businessCategory ?? this.businessCategory,

      marketingProblem: marketingProblem ?? this.marketingProblem,

      providedService: providedService ?? this.providedService,

      additionalNotes: additionalNotes ?? this.additionalNotes,

      employeeName: employeeName ?? this.employeeName,

      createdAt: createdAt,

      lastModified: DateTime.now(),

      isFavorite: isFavorite ?? this.isFavorite,

    );

  }

}

/// محوّل يدوي لتخزين/قراءة كائنات Customer داخل صناديق Hive.

/// كل حقل له رقم ثابت (0 إلى 10) يُستخدم عند القراءة والكتابة؛

/// إضافة حقل جديد مستقبلًا يجب أن تأخذ رقمًا جديدًا لم يُستخدم من قبل،

/// ولا يجوز إعادة استخدام أو تغيير ترقيم حقل موجود.

class CustomerAdapter extends TypeAdapter<Customer> {

  @override

  final int typeId = HiveConstants.customerTypeId;

  @override

  Customer read(BinaryReader reader) {

    final int numOfFields = reader.readByte();

    final Map<int, dynamic> fields = <int, dynamic>{

      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),

    };

    return Customer(

      id: fields[0] as String,

      customerName: fields[1] as String,

      businessName: fields[2] as String,

      businessCategory: fields[3] as String,

      marketingProblem: fields[4] as String,

      providedService: fields[5] as String,

      additionalNotes: fields[6] as String,

      employeeName: fields[7] as String?,

      createdAt: fields[8] as DateTime,

      lastModified: fields[9] as DateTime,

      isFavorite: fields[10] as bool,

    );

  }

  @override

  void write(BinaryWriter writer, Customer obj) {

    writer

      ..writeByte(11) // عدد الحقول الكلي

      ..writeByte(0)

      ..write(obj.id)

      ..writeByte(1)

      ..write(obj.customerName)

      ..writeByte(2)

      ..write(obj.businessName)

      ..writeByte(3)

      ..write(obj.businessCategory)

      ..writeByte(4)

      ..write(obj.marketingProblem)

      ..writeByte(5)

      ..write(obj.providedService)

      ..writeByte(6)

      ..write(obj.additionalNotes)

      ..writeByte(7)

      ..write(obj.employeeName)

      ..writeByte(8)

      ..write(obj.createdAt)

      ..writeByte(9)

      ..write(obj.lastModified)

      ..writeByte(10)

      ..write(obj.isFavorite);

  }

}