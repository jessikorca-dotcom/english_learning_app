import 'dart:convert';

import 'dart:math';

import 'package:crypto/crypto.dart';

/// أداة مسؤولة عن التعامل الآمن مع كلمة مرور المدير:

/// توليد ملح عشوائي، تجزئة كلمة المرور، والتحقق منها لاحقًا.

/// لا يتم تخزين كلمة المرور الأصلية في أي مرحلة، فقط ناتج التجزئة والملح.

class ManagerCredentials {

  ManagerCredentials._();

  /// يولّد قيمة عشوائية فريدة (ملح) تُستخدم مرة واحدة لكل كلمة مرور.

  /// وجود الملح يمنع أن تُنتج كلمتا مرور متطابقتان نفس ناتج التجزئة.

  static String generateSalt({int length = 16}) {

    final Random random = Random.secure();

    final List<int> saltBytes =

        List<int>.generate(length, (_) => random.nextInt(256));

    return base64UrlEncode(saltBytes);

  }

  /// يدمج كلمة المرور مع الملح، ثم يُنتج تجزئة SHA-256 منها كنص Hex.

  static String hashPassword(String password, String salt) {

    final String combined = '$password:$salt';

    final List<int> bytes = utf8.encode(combined);

    final Digest digest = sha256.convert(bytes);

    return digest.toString();

  }

  /// يتحقق مما إذا كانت كلمة المرور المُدخلة تُطابق التجزئة المخزَّنة،

  /// بإعادة حساب التجزئة بنفس الملح المحفوظ ومقارنتها.

  static bool verifyPassword({

    required String enteredPassword,

    required String storedHash,

    required String storedSalt,

  }) {

    final String computedHash = hashPassword(enteredPassword, storedSalt);

    return computedHash == storedHash;

  }

}