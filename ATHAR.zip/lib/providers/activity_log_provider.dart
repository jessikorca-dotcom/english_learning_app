import 'package:flutter/foundation.dart';

import '../core/di/service_locator.dart';

import '../models/activity_log_model.dart';

/// يدير حالة سجل الأنشطة: القراءة الكاملة، وآخر الأنشطة فقط

/// للعرض المختصر في الشاشة الرئيسية.

class ActivityLogProvider extends ChangeNotifier {

  List<ActivityLogEntry> _allActivities = [];

  bool _isLoading = false;

  List<ActivityLogEntry> get allActivities => _allActivities;

  bool get isLoading => _isLoading;

  /// آخر 10 أنشطة فقط، مفيدة لعرض مختصر في الشاشة الرئيسية.

  List<ActivityLogEntry> get recentActivities =>

      _allActivities.take(10).toList();

  /// يحمّل كل سجلات النشاط من المستودع إلى الذاكرة.

  void loadActivities() {

    _isLoading = true;

    notifyListeners();

    _allActivities = ServiceLocator.activityLogRepository.getAllActivities();

    _isLoading = false;

    notifyListeners();

  }

}