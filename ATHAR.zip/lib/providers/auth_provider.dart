import 'package:flutter/foundation.dart';

import '../core/di/service_locator.dart';

import '../services/auth_service.dart';

/// يمثل الدور الحالي للمستخدم داخل التطبيق.

enum UserRole {

  none,

  manager,

  employee,

}

/// يدير حالة المصادقة الحالية للتطبيق: من هو المستخدم الحالي

/// (مدير أو موظف)، وهل تم تسجيل الدخول بنجاح.

class AuthProvider extends ChangeNotifier {

  UserRole _currentRole = UserRole.none;

  String? _loginErrorMessage;

  bool _isLoading = false;

  UserRole get currentRole => _currentRole;

  String? get loginErrorMessage => _loginErrorMessage;

  bool get isLoading => _isLoading;

  bool get isManager => _currentRole == UserRole.manager;

  bool get isEmployee => _currentRole == UserRole.employee;

  bool get isLoggedIn => _currentRole != UserRole.none;

  /// يتحقق مما إذا كان هذا أول تشغيل للتطبيق (لم تُحدَّد كلمة مرور بعد).

  bool checkIsFirstRun() {

    return ServiceLocator.authRepository.isFirstRun();

  }

  /// يُستدعى مرة واحدة فقط من شاشة الإعداد الأول، لتحديد كلمة مرور

  /// المدير لأول مرة.

  Future<void> completeFirstSetup(String password) async {

    _isLoading = true;

    notifyListeners();

    await ServiceLocator.authRepository.setInitialPassword(password);

    _isLoading = false;

    notifyListeners();

  }

  /// يحاول تسجيل دخول المدير بكلمة مرور مُدخلة. يُحدّث الحالة

  /// ويُبلّغ الواجهة بالنجاح أو الفشل.

  Future<bool> loginAsManager(String password) async {

    _isLoading = true;

    _loginErrorMessage = null;

    notifyListeners();

    final bool isValid =

        ServiceLocator.authRepository.verifyManagerPassword(password);

    if (isValid) {

      _currentRole = UserRole.manager;

    } else {

      _loginErrorMessage = 'كلمة المرور غير صحيحة';

    }

    _isLoading = false;

    notifyListeners();

    return isValid;

  }

  /// يسجّل دخول كموظف مباشرة، بدون كلمة مرور، كما حدّدت في المتطلبات.

  void loginAsEmployee() {

    _currentRole = UserRole.employee;

    _loginErrorMessage = null;

    notifyListeners();

  }

  /// يغيّر كلمة مرور المدير، ويعيد نتيجة العملية لتُعرض في الواجهة.

  Future<ChangePasswordResult> changePassword({

    required String currentPassword,

    required String newPassword,

    required int minLength,

  }) async {

    return ServiceLocator.authRepository.changeManagerPassword(

      currentPassword: currentPassword,

      newPassword: newPassword,

      minLength: minLength,

    );

  }

  /// يسجّل الخروج ويعيد الحالة إلى شاشة اختيار الدخول.

  void logout() {

    _currentRole = UserRole.none;

    _loginErrorMessage = null;

    notifyListeners();

  }

  /// يمسح رسالة خطأ الدخول (مثلاً عند إعادة فتح حقل كلمة المرور).

  void clearError() {

    _loginErrorMessage = null;

    notifyListeners();

  }

}