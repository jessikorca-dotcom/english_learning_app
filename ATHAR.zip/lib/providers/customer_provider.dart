import 'package:flutter/foundation.dart';

import '../core/di/service_locator.dart';

import '../models/customer_model.dart';

/// يدير حالة العملاء بالكامل: القائمة النشطة، سلة المحذوفات،

/// المفضلة، والبحث. أي شاشة تعرض عملاء تعتمد على هذا الـ Provider

/// بدل استدعاء الـ Repository مباشرة.

class CustomerProvider extends ChangeNotifier {

  List<Customer> _allCustomers = [];

  List<Customer> _deletedCustomers = [];

  String _searchQuery = '';

  bool _isLoading = false;

  List<Customer> get deletedCustomers => _deletedCustomers;

  bool get isLoading => _isLoading;

  String get searchQuery => _searchQuery;

  /// القائمة المعروضة فعليًا: مفلترة حسب نص البحث الحالي إن وُجد.

  List<Customer> get customers {

    if (_searchQuery.trim().isEmpty) return _allCustomers;

    return ServiceLocator.customerRepository.searchCustomers(_searchQuery);

  }

  List<Customer> get favoriteCustomers =>

      _allCustomers.where((c) => c.isFavorite).toList();

  int get totalCustomersCount => _allCustomers.length;

  /// يحمّل قائمة العملاء من المستودع إلى الذاكرة. يُستدعى عند بدء

  /// التطبيق وبعد كل عملية تُعدِّل البيانات.

  void loadCustomers() {

    _isLoading = true;

    notifyListeners();

    _allCustomers = ServiceLocator.customerRepository.getAllCustomers();

    _isLoading = false;

    notifyListeners();

  }

  /// يحمّل قائمة سلة المحذوفات من المستودع.

  void loadDeletedCustomers() {

    _deletedCustomers =

        ServiceLocator.customerRepository.getDeletedCustomers();

    notifyListeners();

  }

  /// يحدّث نص البحث الحالي ويُبلّغ الواجهة لإعادة العرض فورًا.

  void updateSearchQuery(String query) {

    _searchQuery = query;

    notifyListeners();

  }

  /// يمسح نص البحث ويعيد عرض القائمة الكاملة.

  void clearSearch() {

    _searchQuery = '';

    notifyListeners();

  }

  /// يضيف عميلًا جديدًا، ثم يُعيد تحميل القائمة لتعكس الإضافة فورًا.

  Future<void> addCustomer({

    required String customerName,

    required String businessName,

    required String businessCategory,

    required String marketingProblem,

    required String providedService,

    required String additionalNotes,

    String? employeeName,

    required String performedBy,

  }) async {

    await ServiceLocator.customerRepository.addCustomer(

      customerName: customerName,

      businessName: businessName,

      businessCategory: businessCategory,

      marketingProblem: marketingProblem,

      providedService: providedService,

      additionalNotes: additionalNotes,

      employeeName: employeeName,

      performedBy: performedBy,

    );

    loadCustomers();

  }

  /// يحدّث بيانات عميل موجود، ثم يُعيد تحميل القائمة.

  Future<void> updateCustomer({

    required Customer customer,

    required String performedBy,

    String? customerName,

    String? businessName,

    String? businessCategory,

    String? marketingProblem,

    String? providedService,

    String? additionalNotes,

    String? employeeName,

  }) async {

    await ServiceLocator.customerRepository.updateCustomer(

      customer: customer,

      performedBy: performedBy,

      customerName: customerName,

      businessName: businessName,

      businessCategory: businessCategory,

      marketingProblem: marketingProblem,

      providedService: providedService,

      additionalNotes: additionalNotes,

      employeeName: employeeName,

    );

    loadCustomers();

  }

  /// ينقل عميلًا لسلة المحذوفات، ثم يُحدّث القائمتين (النشطة والمحذوفة).

  Future<void> deleteCustomer({

    required Customer customer,

    required String performedBy,

  }) async {

    await ServiceLocator.customerRepository.softDeleteCustomer(

      customer: customer,

      performedBy: performedBy,

    );

    loadCustomers();

    loadDeletedCustomers();

  }

  /// يستعيد عميلًا من سلة المحذوفات، ثم يُحدّث القائمتين.

  Future<void> restoreCustomer({

    required Customer customer,

    required String performedBy,

  }) async {

    await ServiceLocator.customerRepository.restoreCustomer(

      customer: customer,

      performedBy: performedBy,

    );

    loadCustomers();

    loadDeletedCustomers();

  }

  /// يحذف عميلًا نهائيًا من سلة المحذوفات، بدون رجعة.

  Future<void> permanentlyDeleteCustomer(String customerId) async {

    await ServiceLocator.customerRepository

        .permanentlyDeleteCustomer(customerId);

    loadDeletedCustomers();

  }

  /// يبدّل حالة "مفضّل" لعميل معيّن، ثم يُحدّث القائمة لعكس التغيير.

  Future<void> toggleFavorite(Customer customer) async {

    await ServiceLocator.customerRepository.toggleFavorite(customer);

    loadCustomers();

  }

}