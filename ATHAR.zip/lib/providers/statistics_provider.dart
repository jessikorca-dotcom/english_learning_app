import 'package:flutter/foundation.dart';

import '../models/customer_model.dart';

/// يمثل نتيجة إحصائية واحدة قابلة للعرض (تسمية + قيمة).

class StatisticEntry {

  final String label;

  final int value;

  const StatisticEntry({required this.label, required this.value});

}

/// يحسب إحصائيات العملاء (حسب الفئة، حسب الموظف، النمو الشهري)

/// اعتمادًا على قائمة عملاء يتم تمريرها من CustomerProvider،

/// دون الحاجة لقراءة أي بيانات من التخزين مباشرة.

class StatisticsProvider extends ChangeNotifier {

  List<StatisticEntry> _byCategory = [];

  List<StatisticEntry> _byEmployee = [];

  List<StatisticEntry> _monthlyGrowth = [];

  int _totalCustomers = 0;

  List<StatisticEntry> get byCategory => _byCategory;

  List<StatisticEntry> get byEmployee => _byEmployee;

  List<StatisticEntry> get monthlyGrowth => _monthlyGrowth;

  int get totalCustomers => _totalCustomers;

  /// يعيد حساب كل الإحصائيات بناءً على قائمة عملاء حالية.

  /// يُستدعى من الشاشة عند فتح شاشة الإحصائيات، بعد الحصول على

  /// القائمة من CustomerProvider.

  void recalculate(List<Customer> customers) {

    _totalCustomers = customers.length;

    _byCategory = _groupByCategory(customers);

    _byEmployee = _groupByEmployee(customers);

    _monthlyGrowth = _groupByMonth(customers);

    notifyListeners();

  }

  List<StatisticEntry> _groupByCategory(List<Customer> customers) {

    final Map<String, int> counts = {};

    for (final Customer c in customers) {

      counts[c.businessCategory] = (counts[c.businessCategory] ?? 0) + 1;

    }

    final List<StatisticEntry> result = counts.entries

        .map((e) => StatisticEntry(label: e.key, value: e.value))

        .toList();

    result.sort((a, b) => b.value.compareTo(a.value));

    return result;

  }

  List<StatisticEntry> _groupByEmployee(List<Customer> customers) {

    final Map<String, int> counts = {};

    for (final Customer c in customers) {

      final String name =

          (c.employeeName == null || c.employeeName!.trim().isEmpty)

              ? 'غير محدد'

              : c.employeeName!;

      counts[name] = (counts[name] ?? 0) + 1;

    }

    final List<StatisticEntry> result = counts.entries

        .map((e) => StatisticEntry(label: e.key, value: e.value))

        .toList();

    result.sort((a, b) => b.value.compareTo(a.value));

    return result;

  }

  List<StatisticEntry> _groupByMonth(List<Customer> customers) {

    final Map<String, int> counts = {};

    for (final Customer c in customers) {

      final String monthKey =

          '${c.createdAt.year}-${c.createdAt.month.toString().padLeft(2, '0')}';

      counts[monthKey] = (counts[monthKey] ?? 0) + 1;

    }

    final List<String> sortedKeys = counts.keys.toList()..sort();

    return sortedKeys

        .map((key) => StatisticEntry(label: key, value: counts[key]!))

        .toList();

  }

}