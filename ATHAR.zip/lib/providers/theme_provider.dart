import 'package:flutter/material.dart';

import '../core/constants/hive_constants.dart';

import '../services/hive_service.dart';

/// يدير حالة الوضع الحالي (فاتح/داكن)، ويحفظ التفضيل محليًا

/// بحيث يُستعاد تلقائيًا عند إعادة فتح التطبيق.

class ThemeProvider extends ChangeNotifier {

  bool _isDarkMode = false;

  bool get isDarkMode => _isDarkMode;

  ThemeMode get themeMode =>

      _isDarkMode ? ThemeMode.dark : ThemeMode.light;

  /// يحمّل التفضيل المحفوظ عند بدء التطبيق. القيمة الافتراضية

  /// عند عدم وجود تفضيل سابق هي الوضع الفاتح.

  void loadThemePreference() {

    final bool? stored =

        HiveService.settingsBox.get(HiveConstants.keyIsDarkMode) as bool?;

    _isDarkMode = stored ?? false;

    notifyListeners();

  }

  /// يبدّل الوضع الحالي ويحفظ التفضيل الجديد فورًا.

  Future<void> toggleDarkMode() async {

    _isDarkMode = !_isDarkMode;

    await HiveService.settingsBox

        .put(HiveConstants.keyIsDarkMode, _isDarkMode);

    notifyListeners();

  }

}