import '../models/activity_log_model.dart';

import '../services/activity_log_service.dart';

/// يصف عمليات القراءة والتسجيل الممكنة على سجل الأنشطة.

abstract class ActivityLogRepository {

  Future<void> logActivity({

    required ActivityType type,

    required String customerId,

    required String customerName,

    required String performedBy,

  });

  List<ActivityLogEntry> getAllActivities();

  List<ActivityLogEntry> getRecentActivities({int count});

}

/// التنفيذ الحالي: يعتمد على التخزين المحلي عبر Hive،

/// من خلال [ActivityLogService].

class HiveActivityLogRepository implements ActivityLogRepository {

  @override

  Future<void> logActivity({

    required ActivityType type,

    required String customerId,

    required String customerName,

    required String performedBy,

  }) {

    return ActivityLogService.logActivity(

      type: type,

      customerId: customerId,

      customerName: customerName,

      performedBy: performedBy,

    );

  }

  @override

  List<ActivityLogEntry> getAllActivities() {

    return ActivityLogService.getAllActivities();

  }

  @override

  List<ActivityLogEntry> getRecentActivities({int count = 10}) {

    return ActivityLogService.getRecentActivities(count: count);

  }

}