import '../services/auth_service.dart';

/// يصف عمليات المصادقة الممكنة، دون تحديد آلية التخزين أو التحقق.

abstract class AuthRepository {

  bool isFirstRun();

  Future<void> setInitialPassword(String password);

  bool verifyManagerPassword(String enteredPassword);

  Future<ChangePasswordResult> changeManagerPassword({

    required String currentPassword,

    required String newPassword,

    required int minLength,

  });

}

/// التنفيذ الحالي: يعتمد على التخزين المحلي عبر Hive،

/// من خلال [AuthService].

class LocalAuthRepository implements AuthRepository {

  @override

  bool isFirstRun() => AuthService.isFirstRun();

  @override

  Future<void> setInitialPassword(String password) {

    return AuthService.setInitialPassword(password);

  }

  @override

  bool verifyManagerPassword(String enteredPassword) {

    return AuthService.verifyPassword(enteredPassword);

  }

  @override

  Future<ChangePasswordResult> changeManagerPassword({

    required String currentPassword,

    required String newPassword,

    required int minLength,

  }) {

    return AuthService.changePassword(

      currentPassword: currentPassword,

      newPassword: newPassword,

      minLength: minLength,

    );

  }

}