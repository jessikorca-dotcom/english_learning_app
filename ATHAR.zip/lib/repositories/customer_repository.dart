import '../models/customer_model.dart';

import '../services/customer_service.dart';

/// يصف العمليات الممكنة على بيانات العملاء، دون تحديد مصدر التخزين.

/// أي تنفيذ مستقبلي (محلي أو سحابي) يجب أن يلتزم بهذا العقد بالضبط.

abstract class CustomerRepository {

  Future<Customer> addCustomer({

    required String customerName,

    required String businessName,

    required String businessCategory,

    required String marketingProblem,

    required String providedService,

    required String additionalNotes,

    String? employeeName,

    required String performedBy,

  });

  Future<void> updateCustomer({

    required Customer customer,

    required String performedBy,

    String? customerName,

    String? businessName,

    String? businessCategory,

    String? marketingProblem,

    String? providedService,

    String? additionalNotes,

    String? employeeName,

  });

  Future<void> softDeleteCustomer({

    required Customer customer,

    required String performedBy,

  });

  Future<void> restoreCustomer({

    required Customer customer,

    required String performedBy,

  });

  Future<void> permanentlyDeleteCustomer(String customerId);

  List<Customer> getAllCustomers();

  List<Customer> getDeletedCustomers();

  List<Customer> getFavoriteCustomers();

  Future<void> toggleFavorite(Customer customer);

  List<Customer> searchCustomers(String query);

}

/// التنفيذ الحالي: يعتمد على Hive عبر [CustomerService].

/// هذا هو التنفيذ المستخدم فعليًا في النسخة الأولى (غير المتصلة).

class HiveCustomerRepository implements CustomerRepository {

  @override

  Future<Customer> addCustomer({

    required String customerName,

    required String businessName,

    required String businessCategory,

    required String marketingProblem,

    required String providedService,

    required String additionalNotes,

    String? employeeName,

    required String performedBy,

  }) {

    return CustomerService.addCustomer(

      customerName: customerName,

      businessName: businessName,

      businessCategory: businessCategory,

      marketingProblem: marketingProblem,

      providedService: providedService,

      additionalNotes: additionalNotes,

      employeeName: employeeName,

      performedBy: performedBy,

    );

  }

  @override

  Future<void> updateCustomer({

    required Customer customer,

    required String performedBy,

    String? customerName,

    String? businessName,

    String? businessCategory,

    String? marketingProblem,

    String? providedService,

    String? additionalNotes,

    String? employeeName,

  }) {

    return CustomerService.updateCustomer(

      customer: customer,

      performedBy: performedBy,

      customerName: customerName,

      businessName: businessName,

      businessCategory: businessCategory,

      marketingProblem: marketingProblem,

      providedService: providedService,

      additionalNotes: additionalNotes,

      employeeName: employeeName,

    );

  }

  @override

  Future<void> softDeleteCustomer({

    required Customer customer,

    required String performedBy,

  }) {

    return CustomerService.softDeleteCustomer(

      customer: customer,

      performedBy: performedBy,

    );

  }

  @override

  Future<void> restoreCustomer({

    required Customer customer,

    required String performedBy,

  }) {

    return CustomerService.restoreCustomer(

      customer: customer,

      performedBy: performedBy,

    );

  }

  @override

  Future<void> permanentlyDeleteCustomer(String customerId) {

    return CustomerService.permanentlyDeleteCustomer(customerId);

  }

  @override

  List<Customer> getAllCustomers() => CustomerService.getAllCustomers();

  @override

  List<Customer> getDeletedCustomers() =>

      CustomerService.getDeletedCustomers();

  @override

  List<Customer> getFavoriteCustomers() =>

      CustomerService.getFavoriteCustomers();

  @override

  Future<void> toggleFavorite(Customer customer) {

    return CustomerService.toggleFavorite(customer);

  }

  @override

  List<Customer> searchCustomers(String query) {

    return CustomerService.searchCustomers(query);

  }

}