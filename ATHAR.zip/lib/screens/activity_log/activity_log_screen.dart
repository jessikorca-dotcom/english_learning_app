import 'package:flutter/material.dart';

import 'package:intl/intl.dart';

import 'package:provider/provider.dart';

import '../../core/constants/app_strings.dart';

import '../../core/constants/app_constants.dart';

import '../../models/activity_log_model.dart';

import '../../providers/activity_log_provider.dart';

/// تعرض سجل الأنشطة الكامل، الأحدث أولًا.

class ActivityLogScreen extends StatefulWidget {

  const ActivityLogScreen({super.key});

  @override

  State<ActivityLogScreen> createState() => _ActivityLogScreenState();

}

class _ActivityLogScreenState extends State<ActivityLogScreen> {

  @override

  void initState() {

    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {

      context.read<ActivityLogProvider>().loadActivities();

    });

  }

  String _labelFor(ActivityType type) {

    switch (type) {

      case ActivityType.added:

        return AppStrings.activityAdded;

      case ActivityType.edited:

        return AppStrings.activityEdited;

      case ActivityType.deleted:

        return AppStrings.activityDeleted;

      case ActivityType.restored:

        return AppStrings.activityRestored;

    }

  }

  IconData _iconFor(ActivityType type) {

    switch (type) {

      case ActivityType.added:

        return Icons.person_add_alt_1_outlined;

      case ActivityType.edited:

        return Icons.edit_outlined;

      case ActivityType.deleted:

        return Icons.delete_outline;

      case ActivityType.restored:

        return Icons.restore;

    }

  }

  Color _colorFor(ActivityType type, BuildContext context) {

    switch (type) {

      case ActivityType.added:

        return Colors.green.shade700;

      case ActivityType.edited:

        return Theme.of(context).colorScheme.primary;

      case ActivityType.deleted:

        return Colors.red.shade700;

      case ActivityType.restored:

        return Colors.orange.shade700;

    }

  }

  @override

  Widget build(BuildContext context) {

    final DateFormat dateTimeFormat =

        DateFormat(AppConstants.dateTimeFormatPattern);

    return Scaffold(

      appBar: AppBar(title: Text(AppStrings.activityLog)),

      body: Consumer<ActivityLogProvider>(

        builder: (context, activityProvider, _) {

          final List<ActivityLogEntry> activities =

              activityProvider.allActivities;

          if (activities.isEmpty) {

            return Center(

              child: Padding(

                padding: const EdgeInsets.all(AppConstants.defaultPadding),

                child: Column(

                  mainAxisAlignment: MainAxisAlignment.center,

                  children: [

                    Icon(

                      Icons.history,

                      size: 64,

                      color: Colors.grey.shade400,

                    ),

                    const SizedBox(height: 16),

                    Text(

                      AppStrings.noActivityYet,

                      style: Theme.of(context).textTheme.titleMedium,

                    ),

                  ],

                ),

              ),

            );

          }

          return ListView.separated(

            padding: const EdgeInsets.all(AppConstants.defaultPadding),

            itemCount: activities.length,

            separatorBuilder: (_, __) => const SizedBox(height: 4),

            itemBuilder: (context, index) {

              final ActivityLogEntry entry = activities[index];

              return Card(

                child: ListTile(

                  leading: Icon(

                    _iconFor(entry.type),

                    color: _colorFor(entry.type, context),

                  ),

                  title: Text(

                    '${_labelFor(entry.type)}: ${entry.customerName}',

                    style: Theme.of(context).textTheme.bodyLarge,

                  ),

                  subtitle: Text(

                    '${entry.performedBy} • '

                    '${dateTimeFormat.format(entry.timestamp)}',

                    style: Theme.of(context).textTheme.bodySmall,

                  ),

                ),

              );

            },

          );

        },

      ),

    );

  }

}