import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/constants/app_strings.dart';

import '../../core/constants/app_constants.dart';

import '../../providers/auth_provider.dart';

import 'role_selection_screen.dart';

/// شاشة إعداد كلمة مرور المدير لأول مرة. تظهر مرة واحدة فقط

/// طوال عمر التطبيق على هذا الجهاز.

class FirstSetupScreen extends StatefulWidget {

  const FirstSetupScreen({super.key});

  @override

  State<FirstSetupScreen> createState() => _FirstSetupScreenState();

}

class _FirstSetupScreenState extends State<FirstSetupScreen> {

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _passwordController = TextEditingController();

  final TextEditingController _confirmController = TextEditingController();

  bool _obscurePassword = true;

  bool _obscureConfirm = true;

  bool _isSaving = false;

  @override

  void dispose() {

    _passwordController.dispose();

    _confirmController.dispose();

    super.dispose();

  }

  String? _validatePassword(String? value) {

    if (value == null || value.trim().isEmpty) {

      return AppStrings.requiredField;

    }

    if (value.length < AppConstants.minPasswordLength) {

      return AppStrings.passwordTooShort;

    }

    return null;

  }

  String? _validateConfirm(String? value) {

    if (value == null || value.trim().isEmpty) {

      return AppStrings.requiredField;

    }

    if (value != _passwordController.text) {

      return AppStrings.passwordsDoNotMatch;

    }

    return null;

  }

  Future<void> _handleSave() async {

    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);

    final AuthProvider authProvider = context.read<AuthProvider>();

    await authProvider.completeFirstSetup(_passwordController.text);

    if (!mounted) return;

    setState(() => _isSaving = false);

    Navigator.of(context).pushReplacement(

      MaterialPageRoute(builder: (_) => const RoleSelectionScreen()),

    );

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      body: SafeArea(

        child: Padding(

          padding: const EdgeInsets.all(AppConstants.defaultPadding),

          child: Form(

            key: _formKey,

            child: Column(

              mainAxisAlignment: MainAxisAlignment.center,

              crossAxisAlignment: CrossAxisAlignment.stretch,

              children: [

                Icon(

                  Icons.admin_panel_settings_outlined,

                  size: 72,

                  color: Theme.of(context).colorScheme.primary,

                ),

                const SizedBox(height: 16),

                Text(

                  AppStrings.firstSetupTitle,

                  textAlign: TextAlign.center,

                  style: Theme.of(context).textTheme.headlineMedium,

                ),

                const SizedBox(height: 8),

                Text(

                  AppStrings.firstSetupSubtitle,

                  textAlign: TextAlign.center,

                  style: Theme.of(context).textTheme.bodyMedium,

                ),

                const SizedBox(height: 32),

                TextFormField(

                  controller: _passwordController,

                  obscureText: _obscurePassword,

                  validator: _validatePassword,

                  decoration: InputDecoration(

                    labelText: AppStrings.createPassword,

                    prefixIcon: const Icon(Icons.lock_outline),

                    suffixIcon: IconButton(

                      icon: Icon(

                        _obscurePassword

                            ? Icons.visibility_outlined

                            : Icons.visibility_off_outlined,

                      ),

                      onPressed: () => setState(

                        () => _obscurePassword = !_obscurePassword,

                      ),

                    ),

                  ),

                ),

                const SizedBox(height: 16),

                TextFormField(

                  controller: _confirmController,

                  obscureText: _obscureConfirm,

                  validator: _validateConfirm,

                  decoration: InputDecoration(

                    labelText: AppStrings.confirmPassword,

                    prefixIcon: const Icon(Icons.lock_outline),

                    suffixIcon: IconButton(

                      icon: Icon(

                        _obscureConfirm

                            ? Icons.visibility_outlined

                            : Icons.visibility_off_outlined,

                      ),

                      onPressed: () => setState(

                        () => _obscureConfirm = !_obscureConfirm,

                      ),

                    ),

                  ),

                ),

                const SizedBox(height: 32),

                ElevatedButton(

                  onPressed: _isSaving ? null : _handleSave,

                  child: _isSaving

                      ? const SizedBox(

                          width: 20,

                          height: 20,

                          child: CircularProgressIndicator(

                            strokeWidth: 2,

                            color: Colors.white,

                          ),

                        )

                      : Text(AppStrings.saveAndContinue),

                ),

              ],

            ),

          ),

        ),

      ),

    );

  }

}