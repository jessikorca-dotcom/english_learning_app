import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/constants/app_strings.dart';

import '../../core/constants/app_constants.dart';

import '../../providers/auth_provider.dart';

import '../home/home_screen.dart';

/// شاشة تسجيل دخول المدير عبر كلمة المرور.

class ManagerLoginScreen extends StatefulWidget {

  const ManagerLoginScreen({super.key});

  @override

  State<ManagerLoginScreen> createState() => _ManagerLoginScreenState();

}

class _ManagerLoginScreenState extends State<ManagerLoginScreen> {

  final TextEditingController _passwordController = TextEditingController();

  bool _obscurePassword = true;

  bool _isLoading = false;

  @override

  void dispose() {

    _passwordController.dispose();

    super.dispose();

  }

  Future<void> _handleLogin() async {

    final String password = _passwordController.text;

    if (password.trim().isEmpty) return;

    setState(() => _isLoading = true);

    final AuthProvider authProvider = context.read<AuthProvider>();

    final bool success = await authProvider.loginAsManager(password);

    if (!mounted) return;

    setState(() => _isLoading = false);

    if (success) {

      Navigator.of(context).pushReplacement(

        MaterialPageRoute(builder: (_) => const HomeScreen()),

      );

    }

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(title: Text(AppStrings.manager)),

      body: SafeArea(

        child: Padding(

          padding: const EdgeInsets.all(AppConstants.defaultPadding),

          child: Column(

            mainAxisAlignment: MainAxisAlignment.center,

            crossAxisAlignment: CrossAxisAlignment.stretch,

            children: [

              Icon(

                Icons.lock_person_outlined,

                size: 72,

                color: Theme.of(context).colorScheme.primary,

              ),

              const SizedBox(height: 24),

              Text(

                AppStrings.enterPassword,

                textAlign: TextAlign.center,

                style: Theme.of(context).textTheme.titleLarge,

              ),

              const SizedBox(height: 24),

              Consumer<AuthProvider>(

                builder: (context, authProvider, _) {

                  return TextField(

                    controller: _passwordController,

                    obscureText: _obscurePassword,

                    autofocus: true,

                    onSubmitted: (_) => _handleLogin(),

                    decoration: InputDecoration(

                      labelText: AppStrings.password,

                      prefixIcon: const Icon(Icons.lock_outline),

                      errorText: authProvider.loginErrorMessage,

                      suffixIcon: IconButton(

                        icon: Icon(

                          _obscurePassword

                              ? Icons.visibility_outlined

                              : Icons.visibility_off_outlined,

                        ),

                        onPressed: () => setState(

                          () => _obscurePassword = !_obscurePassword,

                        ),

                      ),

                    ),

                  );

                },

              ),

              const SizedBox(height: 24),

              ElevatedButton(

                onPressed: _isLoading ? null : _handleLogin,

                child: _isLoading

                    ? const SizedBox(

                        width: 20,

                        height: 20,

                        child: CircularProgressIndicator(

                          strokeWidth: 2,

                          color: Colors.white,

                        ),

                      )

                    : Text(AppStrings.login),

              ),

            ],

          ),

        ),

      ),

    );

  }

}