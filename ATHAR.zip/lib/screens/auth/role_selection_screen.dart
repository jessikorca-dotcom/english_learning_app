import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/constants/app_strings.dart';

import '../../core/constants/app_constants.dart';

import '../../providers/auth_provider.dart';

import '../home/home_screen.dart';

import 'manager_login_screen.dart';

/// شاشة اختيار طريقة الدخول: مدير (يتطلب كلمة مرور) أو موظف

/// (دخول مباشر بدون كلمة مرور).

class RoleSelectionScreen extends StatelessWidget {

  const RoleSelectionScreen({super.key});

  void _selectManager(BuildContext context) {

    Navigator.of(context).push(

      MaterialPageRoute(builder: (_) => const ManagerLoginScreen()),

    );

  }

  void _selectEmployee(BuildContext context) {

    context.read<AuthProvider>().loginAsEmployee();

    Navigator.of(context).pushReplacement(

      MaterialPageRoute(builder: (_) => const HomeScreen()),

    );

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      body: SafeArea(

        child: Padding(

          padding: const EdgeInsets.all(AppConstants.defaultPadding),

          child: Column(

            mainAxisAlignment: MainAxisAlignment.center,

            children: [

              Image.asset(

                AppConstants.companyLogoPath,

                width: 100,

                height: 100,

              ),

              const SizedBox(height: 16),

              Text(

                AppStrings.appName,

                style: Theme.of(context).textTheme.headlineMedium,

              ),

              const SizedBox(height: 48),

              Text(

                AppStrings.chooseRole,

                style: Theme.of(context).textTheme.titleMedium,

              ),

              const SizedBox(height: 24),

              _RoleCard(

                icon: Icons.admin_panel_settings_outlined,

                label: AppStrings.manager,

                onTap: () => _selectManager(context),

              ),

              const SizedBox(height: 16),

              _RoleCard(

                icon: Icons.badge_outlined,

                label: AppStrings.employee,

                onTap: () => _selectEmployee(context),

              ),

            ],

          ),

        ),

      ),

    );

  }

}

/// بطاقة قابلة لإعادة الاستخدام لعرض خيار دور واحد (مدير/موظف).

class _RoleCard extends StatelessWidget {

  final IconData icon;

  final String label;

  final VoidCallback onTap;

  const _RoleCard({

    required this.icon,

    required this.label,

    required this.onTap,

  });

  @override

  Widget build(BuildContext context) {

    return Card(

      child: InkWell(

        onTap: onTap,

        borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),

        child: Padding(

          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),

          child: Row(

            children: [

              Icon(icon, size: 32, color: Theme.of(context).colorScheme.primary),

              const SizedBox(width: 16),

              Expanded(

                child: Text(

                  label,

                  style: Theme.of(context).textTheme.titleLarge,

                ),

              ),

              const Icon(Icons.arrow_back_ios, size: 16),

            ],

          ),

        ),

      ),

    );

  }

}