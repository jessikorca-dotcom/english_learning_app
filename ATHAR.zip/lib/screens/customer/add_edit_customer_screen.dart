import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/constants/app_strings.dart';

import '../../core/constants/app_constants.dart';

import '../../models/customer_model.dart';

import '../../providers/auth_provider.dart';

import '../../providers/customer_provider.dart';

/// شاشة إضافة عميل جديد أو تعديل عميل موجود.

/// إن مُرِّر [customer]، تعمل الشاشة في وضع التعديل وتُملأ الحقول

/// ببياناته الحالية. إن كان null، تعمل في وضع الإضافة.

class AddEditCustomerScreen extends StatefulWidget {

  final Customer? customer;

  const AddEditCustomerScreen({super.key, this.customer});

  bool get isEditMode => customer != null;

  @override

  State<AddEditCustomerScreen> createState() => _AddEditCustomerScreenState();

}

class _AddEditCustomerScreenState extends State<AddEditCustomerScreen> {

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  late final TextEditingController _customerNameController;

  late final TextEditingController _businessNameController;

  late final TextEditingController _marketingProblemController;

  late final TextEditingController _providedServiceController;

  late final TextEditingController _notesController;

  late final TextEditingController _employeeNameController;

  late String _selectedCategory;

  bool _isSaving = false;

  @override

  void initState() {

    super.initState();

    final Customer? c = widget.customer;

    _customerNameController = TextEditingController(text: c?.customerName);

    _businessNameController = TextEditingController(text: c?.businessName);

    _marketingProblemController =

        TextEditingController(text: c?.marketingProblem);

    _providedServiceController =

        TextEditingController(text: c?.providedService);

    _notesController = TextEditingController(text: c?.additionalNotes);

    _employeeNameController = TextEditingController(text: c?.employeeName);

    _selectedCategory = c?.businessCategory ??

        AppConstants.defaultBusinessCategories.first;

  }

  @override

  void dispose() {

    _customerNameController.dispose();

    _businessNameController.dispose();

    _marketingProblemController.dispose();

    _providedServiceController.dispose();

    _notesController.dispose();

    _employeeNameController.dispose();

    super.dispose();

  }

  String? _requiredValidator(String? value) {

    if (value == null || value.trim().isEmpty) {

      return AppStrings.requiredField;

    }

    return null;

  }

  Future<void> _handleSave() async {

    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);

    final AuthProvider authProvider = context.read<AuthProvider>();

    final CustomerProvider customerProvider = context.read<CustomerProvider>();

    final String performedBy =

        authProvider.isManager ? AppStrings.manager : AppStrings.employee;

    if (widget.isEditMode) {

      await customerProvider.updateCustomer(

        customer: widget.customer!,

        performedBy: performedBy,

        customerName: _customerNameController.text.trim(),

        businessName: _businessNameController.text.trim(),

        businessCategory: _selectedCategory,

        marketingProblem: _marketingProblemController.text.trim(),

        providedService: _providedServiceController.text.trim(),

        additionalNotes: _notesController.text.trim(),

        employeeName: _employeeNameController.text.trim(),

      );

    } else {

      await customerProvider.addCustomer(

        customerName: _customerNameController.text.trim(),

        businessName: _businessNameController.text.trim(),

        businessCategory: _selectedCategory,

        marketingProblem: _marketingProblemController.text.trim(),

        providedService: _providedServiceController.text.trim(),

        additionalNotes: _notesController.text.trim(),

        employeeName: _employeeNameController.text.trim(),

        performedBy: performedBy,

      );

    }

    if (!mounted) return;

    setState(() => _isSaving = false);

    Navigator.of(context).pop();

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: Text(

          widget.isEditMode ? AppStrings.editCustomer : AppStrings.addCustomer,

        ),

      ),

      body: Form(

        key: _formKey,

        child: ListView(

          padding: const EdgeInsets.all(AppConstants.defaultPadding),

          children: [

            TextFormField(

              controller: _customerNameController,

              validator: _requiredValidator,

              maxLength: AppConstants.maxCustomerNameLength,

              decoration: InputDecoration(labelText: AppStrings.customerName),

            ),

            const SizedBox(height: 12),

            TextFormField(

              controller: _businessNameController,

              validator: _requiredValidator,

              maxLength: AppConstants.maxCustomerNameLength,

              decoration: InputDecoration(labelText: AppStrings.businessName),

            ),

            const SizedBox(height: 12),

            DropdownButtonFormField<String>(

              value: _selectedCategory,

              decoration:

                  InputDecoration(labelText: AppStrings.businessCategory),

              items: AppConstants.defaultBusinessCategories

                  .map(

                    (category) => DropdownMenuItem(

                      value: category,

                      child: Text(category),

                    ),

                  )

                  .toList(),

              onChanged: (value) {

                if (value != null) {

                  setState(() => _selectedCategory = value);

                }

              },

            ),

            const SizedBox(height: 12),

            TextFormField(

              controller: _marketingProblemController,

              validator: _requiredValidator,

              maxLines: 3,

              decoration:

                  InputDecoration(labelText: AppStrings.marketingProblem),

            ),

            const SizedBox(height: 12),

            TextFormField(

              controller: _providedServiceController,

              validator: _requiredValidator,

              maxLines: 3,

              decoration:

                  InputDecoration(labelText: AppStrings.providedService),

            ),

            const SizedBox(height: 12),

            TextFormField(

              controller: _notesController,

              maxLines: 4,

              maxLength: AppConstants.maxNotesLength,

              decoration:

                  InputDecoration(labelText: AppStrings.additionalNotes),

            ),

            const SizedBox(height: 12),

            TextFormField(

              controller: _employeeNameController,

              decoration: InputDecoration(labelText: AppStrings.employeeName),

            ),

            const SizedBox(height: 24),

            ElevatedButton(

              onPressed: _isSaving ? null : _handleSave,

              child: _isSaving

                  ? const SizedBox(

                      width: 20,

                      height: 20,

                      child: CircularProgressIndicator(

                        strokeWidth: 2,

                        color: Colors.white,

                      ),

                    )

                  : Text(AppStrings.save),

            ),

          ],

        ),

      ),

    );

  }

}