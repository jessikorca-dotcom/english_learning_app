import 'package:flutter/material.dart';

import 'package:intl/intl.dart';

import 'package:provider/provider.dart';

import '../../core/constants/app_strings.dart';

import '../../core/constants/app_constants.dart';

import '../../models/customer_model.dart';

import '../../providers/auth_provider.dart';

import '../../providers/customer_provider.dart';

import '../../services/pdf_service.dart';

import '../../services/clipboard_service.dart';

import 'add_edit_customer_screen.dart';

/// تعرض تفاصيل عميل واحد كاملة. إجراءات التعديل/الحذف/النسخ/التصدير

/// متاحة فقط للمدير.

class CustomerDetailsScreen extends StatelessWidget {

  final Customer customer;

  const CustomerDetailsScreen({super.key, required this.customer});

  Future<void> _handleDelete(BuildContext context) async {

    final bool? confirmed = await showDialog<bool>(

      context: context,

      builder: (dialogContext) => AlertDialog(

        title: Text(AppStrings.confirmDeleteTitle),

        content: Text(AppStrings.confirmDeleteMessage),

        actions: [

          TextButton(

            onPressed: () => Navigator.of(dialogContext).pop(false),

            child: Text(AppStrings.cancel),

          ),

          TextButton(

            onPressed: () => Navigator.of(dialogContext).pop(true),

            child: Text(

              AppStrings.delete,

              style: const TextStyle(color: Colors.red),

            ),

          ),

        ],

      ),

    );

    if (confirmed != true || !context.mounted) return;

    await context.read<CustomerProvider>().deleteCustomer(

          customer: customer,

          performedBy: AppStrings.manager,

        );

    if (!context.mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(

      SnackBar(content: Text(AppStrings.deletedSuccessfully)),

    );

    Navigator.of(context).pop();

  }

  Future<void> _handleCopy(BuildContext context) async {

    await ClipboardService.copyCustomerInfo(customer);

    if (!context.mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(

      SnackBar(content: Text(AppStrings.infoCopied)),

    );

  }

  Future<void> _handleExportPdf(BuildContext context) async {

    await PdfService.exportSingleCustomer(customer);

  }

  Future<void> _handleToggleFavorite(BuildContext context) async {

    await context.read<CustomerProvider>().toggleFavorite(customer);

  }

  void _handleEdit(BuildContext context) {

    Navigator.of(context).push(

      MaterialPageRoute(

        builder: (_) => AddEditCustomerScreen(customer: customer),

      ),

    );

  }

  @override

  Widget build(BuildContext context) {

    final bool isManager = context.watch<AuthProvider>().isManager;

    final DateFormat dateFormat = DateFormat(AppConstants.dateFormatPattern);

    final DateFormat timeFormat = DateFormat(AppConstants.timeFormatPattern);

    return Scaffold(

      appBar: AppBar(

        title: Text(AppStrings.customerDetails),

        actions: [

          if (isManager)

            IconButton(

              icon: Icon(

                customer.isFavorite ? Icons.star : Icons.star_outline,

                color: customer.isFavorite ? Colors.amber : null,

              ),

              onPressed: () => _handleToggleFavorite(context),

            ),

          if (isManager)

            IconButton(

              icon: const Icon(Icons.edit_outlined),

              onPressed: () => _handleEdit(context),

            ),

        ],

      ),

      body: ListView(

        padding: const EdgeInsets.all(AppConstants.defaultPadding),

        children: [

          _DetailTile(label: AppStrings.customerName, value: customer.customerName),

          _DetailTile(label: AppStrings.businessName, value: customer.businessName),

          _DetailTile(label: AppStrings.businessCategory, value: customer.businessCategory),

          _DetailTile(label: AppStrings.marketingProblem, value: customer.marketingProblem),

          _DetailTile(label: AppStrings.providedService, value: customer.providedService),

          if (customer.additionalNotes.trim().isNotEmpty)

            _DetailTile(label: AppStrings.additionalNotes, value: customer.additionalNotes),

          if (customer.employeeName != null && customer.employeeName!.trim().isNotEmpty)

            _DetailTile(label: AppStrings.employeeName, value: customer.employeeName!),

          const Divider(height: 32),

          _DetailTile(label: AppStrings.customerId, value: customer.id),

          _DetailTile(

            label: AppStrings.createdAt,

            value: dateFormat.format(customer.createdAt),

          ),

          _DetailTile(

            label: AppStrings.createdTime,

            value: timeFormat.format(customer.createdAt),

          ),

          _DetailTile(

            label: AppStrings.lastModified,

            value: dateFormat.format(customer.lastModified),

          ),

          if (isManager) ...[

            const SizedBox(height: 24),

            Row(

              children: [

                Expanded(

                  child: OutlinedButton.icon(

                    onPressed: () => _handleCopy(context),

                    icon: const Icon(Icons.copy_outlined),

                    label: Text(AppStrings.copyInfo),

                  ),

                ),

                const SizedBox(width: 12),

                Expanded(

                  child: OutlinedButton.icon(

                    onPressed: () => _handleExportPdf(context),

                    icon: const Icon(Icons.picture_as_pdf_outlined),

                    label: Text(AppStrings.exportPdf),

                  ),

                ),

              ],

            ),

            const SizedBox(height: 12),

            SizedBox(

              width: double.infinity,

              child: OutlinedButton.icon(

                onPressed: () => _handleDelete(context),

                style: OutlinedButton.styleFrom(foregroundColor: Colors.red),

                icon: const Icon(Icons.delete_outline),

                label: Text(AppStrings.delete),

              ),

            ),

          ],

        ],

      ),

    );

  }

}

/// عنصر عرض ثنائي (تسمية + قيمة) يُعاد استخدامه لكل حقل في التفاصيل.

class _DetailTile extends StatelessWidget {

  final String label;

  final String value;

  const _DetailTile({required this.label, required this.value});

  @override

  Widget build(BuildContext context) {

    return Padding(

      padding: const EdgeInsets.symmetric(vertical: 8),

      child: Column(

        crossAxisAlignment: CrossAxisAlignment.start,

        children: [

          Text(

            label,

            style: Theme.of(context).textTheme.bodySmall?.copyWith(

                  color: Colors.grey.shade500,

                ),

          ),

          const SizedBox(height: 2),

          Text(value, style: Theme.of(context).textTheme.bodyLarge),

        ],

      ),

    );

  }

}