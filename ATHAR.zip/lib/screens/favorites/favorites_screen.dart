import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/constants/app_strings.dart';

import '../../core/constants/app_constants.dart';

import '../../models/customer_model.dart';

import '../../providers/customer_provider.dart';

import '../customer/customer_details_screen.dart';

/// تعرض قائمة العملاء المفضّلين فقط، المحدَّدين من قِبل المدير.

class FavoritesScreen extends StatelessWidget {

  const FavoritesScreen({super.key});

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(title: Text(AppStrings.favorites)),

      body: Consumer<CustomerProvider>(

        builder: (context, customerProvider, _) {

          final List<Customer> favorites = customerProvider.favoriteCustomers;

          if (favorites.isEmpty) {

            return Center(

              child: Padding(

                padding: const EdgeInsets.all(AppConstants.defaultPadding),

                child: Column(

                  mainAxisAlignment: MainAxisAlignment.center,

                  children: [

                    Icon(

                      Icons.star_outline,

                      size: 64,

                      color: Colors.grey.shade400,

                    ),

                    const SizedBox(height: 16),

                    Text(

                      AppStrings.noFavoritesYet,

                      style: Theme.of(context).textTheme.titleMedium,

                    ),

                  ],

                ),

              ),

            );

          }

          return ListView.builder(

            padding: const EdgeInsets.all(AppConstants.defaultPadding),

            itemCount: favorites.length,

            itemBuilder: (context, index) {

              final Customer customer = favorites[index];

              return Card(

                child: ListTile(

                  contentPadding: const EdgeInsets.symmetric(

                    horizontal: 16,

                    vertical: 8,

                  ),

                  title: Text(

                    customer.customerName,

                    style: Theme.of(context).textTheme.titleMedium,

                  ),

                  subtitle: Text(

                    '${customer.businessName} • ${customer.businessCategory}',

                    style: Theme.of(context).textTheme.bodySmall,

                  ),

                  trailing: const Icon(Icons.star, color: Colors.amber),

                  onTap: () => Navigator.of(context).push(

                    MaterialPageRoute(

                      builder: (_) =>

                          CustomerDetailsScreen(customer: customer),

                    ),

                  ),

                ),

              );

            },

          );

        },

      ),

    );

  }

}