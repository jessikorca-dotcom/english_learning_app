import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/constants/app_strings.dart';

import '../../core/constants/app_constants.dart';

import '../../models/customer_model.dart';

import '../../providers/auth_provider.dart';

import '../../providers/customer_provider.dart';

import '../auth/role_selection_screen.dart';

import '../customer/add_edit_customer_screen.dart';

import '../customer/customer_details_screen.dart';

import '../statistics/statistics_screen.dart';

import '../favorites/favorites_screen.dart';

import '../trash/trash_screen.dart';

import '../activity_log/activity_log_screen.dart';

import '../settings/settings_screen.dart';

/// الشاشة الرئيسية: قائمة العملاء، البحث، وقائمة جانبية بالميزات

/// الإضافية المتاحة للمدير فقط.

class HomeScreen extends StatefulWidget {

  const HomeScreen({super.key});

  @override

  State<HomeScreen> createState() => _HomeScreenState();

}

class _HomeScreenState extends State<HomeScreen> {

  final TextEditingController _searchController = TextEditingController();

  @override

  void initState() {

    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {

      context.read<CustomerProvider>().loadCustomers();

    });

  }

  @override

  void dispose() {

    _searchController.dispose();

    super.dispose();

  }

  void _handleLogout(BuildContext context) {

    context.read<AuthProvider>().logout();

    Navigator.of(context).pushAndRemoveUntil(

      MaterialPageRoute(builder: (_) => const RoleSelectionScreen()),

      (route) => false,

    );

  }

  void _openAddCustomer(BuildContext context) {

    Navigator.of(context).push(

      MaterialPageRoute(builder: (_) => const AddEditCustomerScreen()),

    );

  }

  void _openCustomerDetails(BuildContext context, Customer customer) {

    Navigator.of(context).push(

      MaterialPageRoute(

        builder: (_) => CustomerDetailsScreen(customer: customer),

      ),

    );

  }

  @override

  Widget build(BuildContext context) {

    final AuthProvider authProvider = context.watch<AuthProvider>();

    final bool isManager = authProvider.isManager;

    return Scaffold(

      appBar: AppBar(

        title: Text(AppStrings.customersList),

        actions: [

          IconButton(

            icon: const Icon(Icons.logout),

            tooltip: AppStrings.logout,

            onPressed: () => _handleLogout(context),

          ),

        ],

      ),

      drawer: isManager ? _ManagerDrawer(onLogout: () => _handleLogout(context)) : null,

      body: Column(

        children: [

          Padding(

            padding: const EdgeInsets.all(AppConstants.defaultPadding),

            child: TextField(

              controller: _searchController,

              onChanged: (value) =>

                  context.read<CustomerProvider>().updateSearchQuery(value),

              decoration: InputDecoration(

                hintText: AppStrings.searchHint,

                prefixIcon: const Icon(Icons.search),

                suffixIcon: _searchController.text.isEmpty

                    ? null

                    : IconButton(

                        icon: const Icon(Icons.close),

                        onPressed: () {

                          _searchController.clear();

                          context.read<CustomerProvider>().clearSearch();

                        },

                      ),

              ),

            ),

          ),

          Expanded(

            child: Consumer<CustomerProvider>(

              builder: (context, customerProvider, _) {

                if (customerProvider.isLoading) {

                  return const Center(child: CircularProgressIndicator());

                }

                final List<Customer> customers = customerProvider.customers;

                if (customers.isEmpty) {

                  return _EmptyState(

                    hasSearchQuery: customerProvider.searchQuery.isNotEmpty,

                  );

                }

                return ListView.builder(

                  padding: const EdgeInsets.symmetric(

                    horizontal: AppConstants.defaultPadding,

                  ),

                  itemCount: customers.length,

                  itemBuilder: (context, index) {

                    final Customer customer = customers[index];

                    return _CustomerCard(

                      customer: customer,

                      onTap: () => _openCustomerDetails(context, customer),

                    );

                  },

                );

              },

            ),

          ),

        ],

      ),

      floatingActionButton: FloatingActionButton.extended(

        onPressed: () => _openAddCustomer(context),

        icon: const Icon(Icons.person_add_alt_1_outlined),

        label: Text(AppStrings.addCustomer),

      ),

    );

  }

}

/// القائمة الجانبية الخاصة بالمدير فقط، تحتوي روابط الميزات الإضافية.

class _ManagerDrawer extends StatelessWidget {

  final VoidCallback onLogout;

  const _ManagerDrawer({required this.onLogout});

  @override

  Widget build(BuildContext context) {

    return Drawer(

      child: SafeArea(

        child: Column(

          crossAxisAlignment: CrossAxisAlignment.stretch,

          children: [

            DrawerHeader(

              decoration: BoxDecoration(

                color: Theme.of(context).colorScheme.primary,

              ),

              child: Center(

                child: Image.asset(

                  AppConstants.companyLogoPath,

                  width: 72,

                  height: 72,

                ),

              ),

            ),

            _DrawerItem(

              icon: Icons.bar_chart_outlined,

              label: AppStrings.statistics,

              onTap: () => Navigator.of(context).push(

                MaterialPageRoute(builder: (_) => const StatisticsScreen()),

              ),

            ),

            _DrawerItem(

              icon: Icons.star_outline,

              label: AppStrings.favorites,

              onTap: () => Navigator.of(context).push(

                MaterialPageRoute(builder: (_) => const FavoritesScreen()),

              ),

            ),

            _DrawerItem(

              icon: Icons.delete_outline,

              label: AppStrings.trash,

              onTap: () => Navigator.of(context).push(

                MaterialPageRoute(builder: (_) => const TrashScreen()),

              ),

            ),

            _DrawerItem(

              icon: Icons.history,

              label: AppStrings.activityLog,

              onTap: () => Navigator.of(context).push(

                MaterialPageRoute(builder: (_) => const ActivityLogScreen()),

              ),

            ),

            _DrawerItem(

              icon: Icons.settings_outlined,

              label: AppStrings.settings,

              onTap: () => Navigator.of(context).push(

                MaterialPageRoute(builder: (_) => const SettingsScreen()),

              ),

            ),

            const Spacer(),

            const Divider(),

            _DrawerItem(

              icon: Icons.logout,

              label: AppStrings.logout,

              onTap: onLogout,

            ),

          ],

        ),

      ),

    );

  }

}

class _DrawerItem extends StatelessWidget {

  final IconData icon;

  final String label;

  final VoidCallback onTap;

  const _DrawerItem({

    required this.icon,

    required this.label,

    required this.onTap,

  });

  @override

  Widget build(BuildContext context) {

    return ListTile(

      leading: Icon(icon),

      title: Text(label),

      onTap: () {

        Navigator.of(context).pop(); // إغلاق الـ Drawer قبل الانتقال

        onTap();

      },

    );

  }

}

/// بطاقة عرض عميل واحد داخل القائمة الرئيسية.

class _CustomerCard extends StatelessWidget {

  final Customer customer;

  final VoidCallback onTap;

  const _CustomerCard({required this.customer, required this.onTap});

  @override

  Widget build(BuildContext context) {

    return Card(

      child: ListTile(

        onTap: onTap,

        contentPadding: const EdgeInsets.symmetric(

          horizontal: 16,

          vertical: 8,

        ),

        title: Text(

          customer.customerName,

          style: Theme.of(context).textTheme.titleMedium,

        ),

        subtitle: Text(

          '${customer.businessName} • ${customer.businessCategory}',

          style: Theme.of(context).textTheme.bodySmall,

        ),

        trailing: customer.isFavorite

            ? const Icon(Icons.star, color: Colors.amber)

            : null,

      ),

    );

  }

}

/// الحالة الفارغة: تختلف رسالتها حسب وجود بحث نشط أم لا.

class _EmptyState extends StatelessWidget {

  final bool hasSearchQuery;

  const _EmptyState({required this.hasSearchQuery});

  @override

  Widget build(BuildContext context) {

    return Center(

      child: Padding(

        padding: const EdgeInsets.all(AppConstants.defaultPadding),

        child: Column(

          mainAxisAlignment: MainAxisAlignment.center,

          children: [

            Icon(

              Icons.people_outline,

              size: 64,

              color: Colors.grey.shade400,

            ),

            const SizedBox(height: 16),

            Text(

              AppStrings.noCustomersYet,

              style: Theme.of(context).textTheme.titleMedium,

            ),

            if (!hasSearchQuery) ...[

              const SizedBox(height: 4),

              Text(

                AppStrings.addFirstCustomer,

                style: Theme.of(context).textTheme.bodySmall,

              ),

            ],

          ],

        ),

      ),

    );

  }

}