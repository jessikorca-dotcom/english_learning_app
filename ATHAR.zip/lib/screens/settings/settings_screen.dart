import '../../services/auth_service.dart';

//import '../../services/auth_service.dart';

import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/constants/app_strings.dart';

import '../../core/constants/app_constants.dart';

import '../../providers/auth_provider.dart';

import '../../providers/theme_provider.dart';

import '../../services/backup_service.dart';

/// شاشة الإعدادات: تغيير كلمة مرور المدير، النسخ الاحتياطي،

/// والتبديل بين الوضع الفاتح والداكن.

class SettingsScreen extends StatelessWidget {

  const SettingsScreen({super.key});

  Future<void> _showChangePasswordDialog(BuildContext context) async {

    final GlobalKey<FormState> formKey = GlobalKey<FormState>();

    final TextEditingController currentController = TextEditingController();

    final TextEditingController newController = TextEditingController();

    String? errorText;

    await showDialog(

      context: context,

      builder: (dialogContext) {

        return StatefulBuilder(

          builder: (context, setState) {

            return AlertDialog(

              title: Text(AppStrings.changePassword),

              content: Form(

                key: formKey,

                child: Column(

                  mainAxisSize: MainAxisSize.min,

                  children: [

                    TextField(

                      controller: currentController,

                      obscureText: true,

                      decoration: InputDecoration(

                        labelText: AppStrings.currentPassword,

                      ),

                    ),

                    const SizedBox(height: 12),

                    TextField(

                      controller: newController,

                      obscureText: true,

                      decoration: InputDecoration(

                        labelText: AppStrings.newPassword,

                        errorText: errorText,

                      ),

                    ),

                  ],

                ),

              ),

              actions: [

                TextButton(

                  onPressed: () => Navigator.of(dialogContext).pop(),

                  child: Text(AppStrings.cancel),

                ),

                TextButton(

                  onPressed: () async {

                    final result =

                        await dialogContext.read<AuthProvider>().changePassword(

                              currentPassword: currentController.text,

                              newPassword: newController.text,

                              minLength: AppConstants.minPasswordLength,

                            );

                    switch (result) {

                      case ChangePasswordResult.success:

                        Navigator.of(dialogContext).pop();

                        if (context.mounted) {

                          ScaffoldMessenger.of(context).showSnackBar(

                            SnackBar(

                              content: Text(AppStrings.passwordChanged),

                            ),

                          );

                        }

                        break;

                      case ChangePasswordResult.wrongCurrentPassword:

                        setState(() => errorText = AppStrings.wrongPassword);

                        break;

                      case ChangePasswordResult.newPasswordTooShort:

                        setState(

                          () => errorText = AppStrings.passwordTooShort,

                        );

                        break;

                    }

                  },

                  child: Text(AppStrings.save),

                ),

              ],

            );

          },

        );

      },

    );

  }

  Future<void> _handleExportBackup(BuildContext context) async {

    await BackupService.exportBackup();

    if (!context.mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(

      SnackBar(content: Text(AppStrings.backupExported)),

    );

  }

  Future<void> _handleImportBackup(BuildContext context) async {

    final bool success = await BackupService.importBackup();

    if (!context.mounted) return;

    if (success) {

      ScaffoldMessenger.of(context).showSnackBar(

        SnackBar(content: Text(AppStrings.backupImported)),

      );

    } else {

      ScaffoldMessenger.of(context).showSnackBar(

        SnackBar(content: Text(AppStrings.somethingWentWrong)),

      );

    }

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(title: Text(AppStrings.settings)),

      body: ListView(

        padding: const EdgeInsets.all(AppConstants.defaultPadding),

        children: [

          Card(

            child: ListTile(

              leading: const Icon(Icons.lock_reset_outlined),

              title: Text(AppStrings.changePassword),

              onTap: () => _showChangePasswordDialog(context),

            ),

          ),

          const SizedBox(height: 12),

          Consumer<ThemeProvider>(

            builder: (context, themeProvider, _) {

              return Card(

                child: SwitchListTile(

                  secondary: const Icon(Icons.dark_mode_outlined),

                  title: Text(AppStrings.darkMode),

                  value: themeProvider.isDarkMode,

                  onChanged: (_) => themeProvider.toggleDarkMode(),

                ),

              );

            },

          ),

          const SizedBox(height: 24),

          Text(

            AppStrings.backup,

            style: Theme.of(context).textTheme.titleLarge,

          ),

          const SizedBox(height: 12),

          Card(

            child: ListTile(

              leading: const Icon(Icons.upload_file_outlined),

              title: Text(AppStrings.exportBackup),

              onTap: () => _handleExportBackup(context),

            ),

          ),

          const SizedBox(height: 8),

          Card(

            child: ListTile(

              leading: const Icon(Icons.download_outlined),

              title: Text(AppStrings.importBackup),

              onTap: () => _handleImportBackup(context),

            ),

          ),

        ],

      ),

    );

  }

}