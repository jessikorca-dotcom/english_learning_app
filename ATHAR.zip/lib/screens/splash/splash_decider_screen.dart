import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/theme/app_theme.dart';

import '../../core/constants/app_constants.dart';

import '../../providers/auth_provider.dart';

import '../auth/first_setup_screen.dart';

import '../auth/role_selection_screen.dart';

/// شاشة انتقالية قصيرة تقرر الوجهة الأولى للمستخدم عند فتح التطبيق،

/// بناءً على ما إذا كان الإعداد الأول قد تم أم لا.

class SplashDeciderScreen extends StatefulWidget {

  const SplashDeciderScreen({super.key});

  @override

  State<SplashDeciderScreen> createState() => _SplashDeciderScreenState();

}

class _SplashDeciderScreenState extends State<SplashDeciderScreen> {

  @override

  void initState() {

    super.initState();

    // نؤجل القرار لما بعد اكتمال بناء أول إطار، لأن التنقل يحتاج

    // BuildContext جاهزًا بالكامل.

    WidgetsBinding.instance.addPostFrameCallback((_) => _decideDestination());

  }

  void _decideDestination() {

    final AuthProvider authProvider =

        context.read<AuthProvider>();

    final bool isFirstRun = authProvider.checkIsFirstRun();

    final Widget destination =

        isFirstRun ? const FirstSetupScreen() : const RoleSelectionScreen();

    Navigator.of(context).pushReplacement(

      MaterialPageRoute(builder: (_) => destination),

    );

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: AppTheme.accentColor.withValues(alpha: 0.05),

      body: Center(

        child: Column(

          mainAxisAlignment: MainAxisAlignment.center,

          children: [

            Image.asset(

              AppConstants.companyLogoPath,

              width: 120,

              height: 120,

            ),

            const SizedBox(height: 24),

            const CircularProgressIndicator(),

          ],

        ),

      ),

    );

  }

}