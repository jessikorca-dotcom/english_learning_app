import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

import '../../core/constants/app_strings.dart';

import '../../core/constants/app_constants.dart';

import '../../providers/customer_provider.dart';

import '../../providers/statistics_provider.dart';

/// شاشة الإحصائيات: إجمالي العملاء، التوزيع حسب الفئة والموظف.

class StatisticsScreen extends StatefulWidget {

  const StatisticsScreen({super.key});

  @override

  State<StatisticsScreen> createState() => _StatisticsScreenState();

}

class _StatisticsScreenState extends State<StatisticsScreen> {

  @override

  void initState() {

    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {

      final customers = context.read<CustomerProvider>().customers;

      context.read<StatisticsProvider>().recalculate(customers);

    });

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(title: Text(AppStrings.statistics)),

      body: Consumer<StatisticsProvider>(

        builder: (context, stats, _) {

          return ListView(

            padding: const EdgeInsets.all(AppConstants.defaultPadding),

            children: [

              _TotalCard(total: stats.totalCustomers),

              const SizedBox(height: 24),

              Text(

                AppStrings.byCategory,

                style: Theme.of(context).textTheme.titleLarge,

              ),

              const SizedBox(height: 12),

              if (stats.byCategory.isEmpty)

                _EmptyStatsHint()

              else

                ...stats.byCategory.map(

                  (entry) => _StatBar(

                    label: entry.label,

                    value: entry.value,

                    total: stats.totalCustomers,

                  ),

                ),

              const SizedBox(height: 24),

              Text(

                AppStrings.byEmployee,

                style: Theme.of(context).textTheme.titleLarge,

              ),

              const SizedBox(height: 12),

              if (stats.byEmployee.isEmpty)

                _EmptyStatsHint()

              else

                ...stats.byEmployee.map(

                  (entry) => _StatBar(

                    label: entry.label,

                    value: entry.value,

                    total: stats.totalCustomers,

                  ),

                ),

            ],

          );

        },

      ),

    );

  }

}

/// بطاقة تعرض إجمالي عدد العملاء بشكل بارز أعلى الشاشة.

class _TotalCard extends StatelessWidget {

  final int total;

  const _TotalCard({required this.total});

  @override

  Widget build(BuildContext context) {

    return Card(

      child: Padding(

        padding: const EdgeInsets.all(20),

        child: Column(

          children: [

            Text(

              '$total',

              style: Theme.of(context).textTheme.headlineMedium?.copyWith(

                    fontSize: 36,

                    color: Theme.of(context).colorScheme.primary,

                  ),

            ),

            const SizedBox(height: 4),

            Text(

              AppStrings.totalCustomers,

              style: Theme.of(context).textTheme.bodyMedium,

            ),

          ],

        ),

      ),

    );

  }

}

/// شريط نسبي واحد يعرض تسمية وقيمة ونسبتها من الإجمالي.

class _StatBar extends StatelessWidget {

  final String label;

  final int value;

  final int total;

  const _StatBar({

    required this.label,

    required this.value,

    required this.total,

  });

  @override

  Widget build(BuildContext context) {

    final double ratio = total == 0 ? 0 : value / total;

    return Padding(

      padding: const EdgeInsets.symmetric(vertical: 6),

      child: Column(

        crossAxisAlignment: CrossAxisAlignment.start,

        children: [

          Row(

            mainAxisAlignment: MainAxisAlignment.spaceBetween,

            children: [

              Expanded(

                child: Text(

                  label,

                  style: Theme.of(context).textTheme.bodyMedium,

                ),

              ),

              Text(

                '$value',

                style: Theme.of(context).textTheme.bodyMedium?.copyWith(

                      fontWeight: FontWeight.bold,

                    ),

              ),

            ],

          ),

          const SizedBox(height: 4),

          ClipRRect(

            borderRadius: BorderRadius.circular(6),

            child: LinearProgressIndicator(

              value: ratio,

              minHeight: 8,

              backgroundColor: Colors.grey.shade200,

            ),

          ),

        ],

      ),

    );

  }

}

/// تلميح بسيط عند عدم وجود بيانات كافية لعرض إحصائية.

class _EmptyStatsHint extends StatelessWidget {

  @override

  Widget build(BuildContext context) {

    return Padding(

      padding: const EdgeInsets.symmetric(vertical: 12),

      child: Text(

        AppStrings.noCustomersYet,

        style: Theme.of(context).textTheme.bodySmall,

      ),

    );

  }

}