import 'package:flutter/material.dart';

import 'package:intl/intl.dart';

import 'package:provider/provider.dart';

import '../../core/constants/app_strings.dart';

import '../../core/constants/app_constants.dart';

import '../../models/customer_model.dart';

import '../../providers/customer_provider.dart';

/// تعرض العملاء المحذوفين مؤقتًا (سلة المحذوفات) مع خياري

/// الاستعادة أو الحذف النهائي.

class TrashScreen extends StatefulWidget {

  const TrashScreen({super.key});

  @override

  State<TrashScreen> createState() => _TrashScreenState();

}

class _TrashScreenState extends State<TrashScreen> {

  @override

  void initState() {

    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {

      context.read<CustomerProvider>().loadDeletedCustomers();

    });

  }

  bool _isOldEnoughToWarn(Customer customer) {

    final int daysSinceDeleted =

        DateTime.now().difference(customer.lastModified).inDays;

    return daysSinceDeleted >= AppConstants.trashRetentionDays;

  }

  Future<void> _handleRestore(BuildContext context, Customer customer) async {

    await context.read<CustomerProvider>().restoreCustomer(

          customer: customer,

          performedBy: AppStrings.manager,

        );

    if (!context.mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(

      SnackBar(content: Text(AppStrings.restoredSuccessfully)),

    );

  }

  Future<void> _handlePermanentDelete(

    BuildContext context,

    Customer customer,

  ) async {

    final bool? confirmed = await showDialog<bool>(

      context: context,

      builder: (dialogContext) => AlertDialog(

        title: Text(AppStrings.confirmDeleteTitle),

        content: Text(AppStrings.permanentDeleteWarning),

        actions: [

          TextButton(

            onPressed: () => Navigator.of(dialogContext).pop(false),

            child: Text(AppStrings.cancel),

          ),

          TextButton(

            onPressed: () => Navigator.of(dialogContext).pop(true),

            child: Text(

              AppStrings.delete,

              style: const TextStyle(color: Colors.red),

            ),

          ),

        ],

      ),

    );

    if (confirmed != true || !context.mounted) return;

    await context

        .read<CustomerProvider>()

        .permanentlyDeleteCustomer(customer.id);

  }

  @override

  Widget build(BuildContext context) {

    final DateFormat dateFormat = DateFormat(AppConstants.dateFormatPattern);

    return Scaffold(

      appBar: AppBar(title: Text(AppStrings.trash)),

      body: Consumer<CustomerProvider>(

        builder: (context, customerProvider, _) {

          final List<Customer> deleted = customerProvider.deletedCustomers;

          if (deleted.isEmpty) {

            return Center(

              child: Padding(

                padding: const EdgeInsets.all(AppConstants.defaultPadding),

                child: Column(

                  mainAxisAlignment: MainAxisAlignment.center,

                  children: [

                    Icon(

                      Icons.delete_outline,

                      size: 64,

                      color: Colors.grey.shade400,

                    ),

                    const SizedBox(height: 16),

                    Text(

                      AppStrings.emptyTrash,

                      style: Theme.of(context).textTheme.titleMedium,

                    ),

                  ],

                ),

              ),

            );

          }

          return ListView.builder(

            padding: const EdgeInsets.all(AppConstants.defaultPadding),

            itemCount: deleted.length,

            itemBuilder: (context, index) {

              final Customer customer = deleted[index];

              final bool showWarning = _isOldEnoughToWarn(customer);

              return Card(

                child: Padding(

                  padding: const EdgeInsets.all(12),

                  child: Column(

                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [

                      Row(

                        children: [

                          Expanded(

                            child: Text(

                              customer.customerName,

                              style: Theme.of(context).textTheme.titleMedium,

                            ),

                          ),

                          if (showWarning)

                            Icon(

                              Icons.warning_amber_rounded,

                              color: Colors.orange.shade700,

                              size: 20,

                            ),

                        ],

                      ),

                      const SizedBox(height: 4),

                      Text(

                        customer.businessName,

                        style: Theme.of(context).textTheme.bodySmall,

                      ),

                      const SizedBox(height: 4),

                      Text(

                        '${AppStrings.lastModified}: '

                        '${dateFormat.format(customer.lastModified)}',

                        style: Theme.of(context).textTheme.bodySmall,

                      ),

                      const SizedBox(height: 12),

                      Row(

                        children: [

                          Expanded(

                            child: OutlinedButton.icon(

                              onPressed: () => _handleRestore(context, customer),

                              icon: const Icon(Icons.restore),

                              label: Text(AppStrings.restore),

                            ),

                          ),

                          const SizedBox(width: 8),

                          Expanded(

                            child: OutlinedButton.icon(

                              onPressed: () =>

                                  _handlePermanentDelete(context, customer),

                              style: OutlinedButton.styleFrom(

                                foregroundColor: Colors.red,

                              ),

                              icon: const Icon(Icons.delete_forever_outlined),

                              label: Text(AppStrings.delete),

                            ),

                          ),

                        ],

                      ),

                    ],

                  ),

                ),

              );

            },

          );

        },

      ),

    );

  }

}