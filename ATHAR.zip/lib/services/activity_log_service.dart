import 'package:uuid/uuid.dart';

import '../models/activity_log_model.dart';

import 'hive_service.dart';

/// يدير تسجيل وقراءة سجل الأنشطة. أي عملية تُجرى على عميل (إضافة،

/// تعديل، حذف، استعادة) يجب أن تستدعي [logActivity] لتوثيقها.

class ActivityLogService {

  ActivityLogService._();

  static const Uuid _uuid = Uuid();

  /// يسجّل نشاطًا جديدًا في السجل.

  static Future<void> logActivity({

    required ActivityType type,

    required String customerId,

    required String customerName,

    required String performedBy,

  }) async {

    final ActivityLogEntry entry = ActivityLogEntry(

      id: _uuid.v4(),

      type: type,

      customerId: customerId,

      customerName: customerName,

      performedBy: performedBy,

      timestamp: DateTime.now(),

    );

    await HiveService.activityLogBox.add(entry);

  }

  /// يعيد كل سجلات النشاط، الأحدث أولًا.

  static List<ActivityLogEntry> getAllActivities() {

    final List<ActivityLogEntry> activities =

        HiveService.activityLogBox.values.toList();

    activities.sort((a, b) => b.timestamp.compareTo(a.timestamp));

    return activities;

  }

  /// يعيد آخر [count] نشاط فقط، مفيد لعرض "آخر الأنشطة" في الشاشة

  /// الرئيسية دون تحميل السجل الكامل.

  static List<ActivityLogEntry> getRecentActivities({int count = 10}) {

    final List<ActivityLogEntry> all = getAllActivities();

    return all.take(count).toList();

  }

}