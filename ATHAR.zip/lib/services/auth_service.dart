import '../core/constants/hive_constants.dart';

import '../models/manager_credentials_model.dart';

import 'hive_service.dart';

/// نتيجة عملية تغيير كلمة المرور، لتوضيح سبب الفشل إن حدث بدل مجرد

/// إعادة true/false بلا سياق.

enum ChangePasswordResult {

  success,

  wrongCurrentPassword,

  newPasswordTooShort,

}

/// يدير كل ما يخص هوية المدير: الإعداد الأول، تسجيل الدخول، وتغيير

/// كلمة المرور. لا يخزّن كلمة المرور نفسها في أي مرحلة، فقط تجزئتها.

class AuthService {

  AuthService._();

  /// يتحقق مما إذا كان هذا أول تشغيل للتطبيق (لم تُحدَّد كلمة مرور بعد).

  static bool isFirstRun() {

    final bool? stored =

        HiveService.settingsBox.get(HiveConstants.keyIsFirstRun) as bool?;

    // في حال عدم وجود القيمة إطلاقًا (أول مرة فعليًا)، نعتبرها true

    return stored ?? true;

  }

  /// يُستدعى مرة واحدة فقط عند الإعداد الأول: يولّد ملحًا جديدًا،

  /// يجزّئ كلمة المرور، ويخزّن كل شيء، ثم يُعلّم أن الإعداد اكتمل.

  static Future<void> setInitialPassword(String password) async {

    final String salt = ManagerCredentials.generateSalt();

    final String hash = ManagerCredentials.hashPassword(password, salt);

    await HiveService.settingsBox

        .put(HiveConstants.keyManagerPasswordSalt, salt);

    await HiveService.settingsBox

        .put(HiveConstants.keyManagerPasswordHash, hash);

    await HiveService.settingsBox.put(HiveConstants.keyIsFirstRun, false);

  }

  /// يتحقق من صحة كلمة مرور مُدخلة عند محاولة دخول المدير.

  /// يعيد false إذا لم تكن هناك كلمة مرور مخزَّنة أصلًا (حالة غير متوقعة).

  static bool verifyPassword(String enteredPassword) {

    final String? storedHash =

        HiveService.settingsBox.get(HiveConstants.keyManagerPasswordHash)

            as String?;

    final String? storedSalt =

        HiveService.settingsBox.get(HiveConstants.keyManagerPasswordSalt)

            as String?;

    if (storedHash == null || storedSalt == null) return false;

    return ManagerCredentials.verifyPassword(

      enteredPassword: enteredPassword,

      storedHash: storedHash,

      storedSalt: storedSalt,

    );

  }

  /// يغيّر كلمة مرور المدير، بشرط التحقق أولًا من كلمة المرور الحالية.

  static Future<ChangePasswordResult> changePassword({

    required String currentPassword,

    required String newPassword,

    required int minLength,

  }) async {

    if (!verifyPassword(currentPassword)) {

      return ChangePasswordResult.wrongCurrentPassword;

    }

    if (newPassword.length < minLength) {

      return ChangePasswordResult.newPasswordTooShort;

    }

    final String newSalt = ManagerCredentials.generateSalt();

    final String newHash = ManagerCredentials.hashPassword(

      newPassword,

      newSalt,

    );

    await HiveService.settingsBox

        .put(HiveConstants.keyManagerPasswordSalt, newSalt);

    await HiveService.settingsBox

        .put(HiveConstants.keyManagerPasswordHash, newHash);

    return ChangePasswordResult.success;

  }

}