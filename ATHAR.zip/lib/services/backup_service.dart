import 'dart:convert';

import 'dart:io';

import 'package:file_picker/file_picker.dart';

import 'package:path_provider/path_provider.dart';

import 'package:share_plus/share_plus.dart';

import '../models/customer_model.dart';

import '../models/activity_log_model.dart';

import 'hive_service.dart';

/// يدير تصدير واستيراد نسخة احتياطية كاملة من بيانات التطبيق

/// بصيغة JSON، للحماية من فقدان البيانات على الهاتف الوحيد.

class BackupService {

  BackupService._();

  // ============ التصدير ============

  /// يجمع كل بيانات التطبيق في ملف JSON واحد، ثم يفتح واجهة المشاركة

  /// حتى يحفظه المستخدم يدويًا في مكان آمن (بريد، Drive، إلخ).

  static Future<void> exportBackup() async {

    final Map<String, dynamic> backupData = {

      'exportedAt': DateTime.now().toIso8601String(),

      'customers': HiveService.customersBox.values

          .map(_customerToJson)

          .toList(),

      'deletedCustomers': HiveService.deletedCustomersBox.values

          .map(_customerToJson)

          .toList(),

      'activityLog': HiveService.activityLogBox.values

          .map(_activityToJson)

          .toList(),

    };

    final String jsonString = const JsonEncoder.withIndent(

      '  ',

    ).convert(backupData);

    final Directory tempDir = await getTemporaryDirectory();

    final String fileName =

        'athar_backup_${DateTime.now().millisecondsSinceEpoch}.json';

    final File file = File('${tempDir.path}/$fileName');

    await file.writeAsString(jsonString);

    await Share.shareXFiles([XFile(file.path)], text: 'نسخة احتياطية - أثر');

  }

  // ============ الاستيراد ============

  /// يفتح نافذة اختيار ملف، ويستعيد كل البيانات منه إلى Hive.

  /// يعيد true عند النجاح، و false عند الإلغاء أو حدوث خطأ.

  static Future<bool> importBackup() async {

    try {

      final FilePickerResult? result = await FilePicker.platform.pickFiles(

        type: FileType.custom,

        allowedExtensions: ['json'],

      );

      if (result == null || result.files.single.path == null) {

        return false; // المستخدم ألغى الاختيار

      }

      final File file = File(result.files.single.path!);

      final String content = await file.readAsString();

      final Map<String, dynamic> data =

          jsonDecode(content) as Map<String, dynamic>;

      final List<dynamic> customersJson =

          data['customers'] as List<dynamic>? ?? [];

      final List<dynamic> deletedJson =

          data['deletedCustomers'] as List<dynamic>? ?? [];

      final List<dynamic> activityJson =

          data['activityLog'] as List<dynamic>? ?? [];

      for (final dynamic item in customersJson) {

        final Customer customer =

            _customerFromJson(item as Map<String, dynamic>);

        await HiveService.customersBox.put(customer.id, customer);

      }

      for (final dynamic item in deletedJson) {

        final Customer customer =

            _customerFromJson(item as Map<String, dynamic>);

        await HiveService.deletedCustomersBox.put(customer.id, customer);

      }

      for (final dynamic item in activityJson) {

        final ActivityLogEntry entry =

            _activityFromJson(item as Map<String, dynamic>);

        await HiveService.activityLogBox.add(entry);

      }

      return true;

    } catch (_) {

      return false;

    }

  }

  // ============ تحويل النماذج من وإلى JSON ============

  // تحويل يدوي بسيط، بما أننا لا نستخدم build_runner لتوليد toJson/fromJson.

  static Map<String, dynamic> _customerToJson(Customer c) {

    return {

      'id': c.id,

      'customerName': c.customerName,

      'businessName': c.businessName,

      'businessCategory': c.businessCategory,

      'marketingProblem': c.marketingProblem,

      'providedService': c.providedService,

      'additionalNotes': c.additionalNotes,

      'employeeName': c.employeeName,

      'createdAt': c.createdAt.toIso8601String(),

      'lastModified': c.lastModified.toIso8601String(),

      'isFavorite': c.isFavorite,

    };

  }

  static Customer _customerFromJson(Map<String, dynamic> json) {

    return Customer(

      id: json['id'] as String,

      customerName: json['customerName'] as String,

      businessName: json['businessName'] as String,

      businessCategory: json['businessCategory'] as String,

      marketingProblem: json['marketingProblem'] as String,

      providedService: json['providedService'] as String,

      additionalNotes: json['additionalNotes'] as String,

      employeeName: json['employeeName'] as String?,

      createdAt: DateTime.parse(json['createdAt'] as String),

      lastModified: DateTime.parse(json['lastModified'] as String),

      isFavorite: json['isFavorite'] as bool? ?? false,

    );

  }

  static Map<String, dynamic> _activityToJson(ActivityLogEntry a) {

    return {

      'id': a.id,

      'type': a.type.index,

      'customerId': a.customerId,

      'customerName': a.customerName,

      'performedBy': a.performedBy,

      'timestamp': a.timestamp.toIso8601String(),

    };

  }

  static ActivityLogEntry _activityFromJson(Map<String, dynamic> json) {

    return ActivityLogEntry(

      id: json['id'] as String,

      type: ActivityType.values[json['type'] as int],

      customerId: json['customerId'] as String,

      customerName: json['customerName'] as String,

      performedBy: json['performedBy'] as String,

      timestamp: DateTime.parse(json['timestamp'] as String),

    );

  }

}