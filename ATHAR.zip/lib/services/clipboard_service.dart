import 'package:flutter/services.dart';

import 'package:intl/intl.dart';

import '../core/constants/app_strings.dart';

import '../core/constants/app_constants.dart';

import '../models/customer_model.dart';

/// مسؤول عن نسخ بيانات العميل إلى حافظة الجهاز بصيغة نصية

/// عربية منظمة وسهلة القراءة.

class ClipboardService {

  ClipboardService._();

  /// ينسخ كل بيانات العميل كنص واحد منظم إلى الحافظة.

  static Future<void> copyCustomerInfo(Customer customer) async {

    final String text = _buildCustomerText(customer);

    await Clipboard.setData(ClipboardData(text: text));

  }

  static String _buildCustomerText(Customer customer) {

    final DateFormat dateFormat = DateFormat(AppConstants.dateFormatPattern);

    final DateFormat timeFormat = DateFormat(AppConstants.timeFormatPattern);

    final StringBuffer buffer = StringBuffer();

    buffer.writeln('${AppStrings.customerName}: ${customer.customerName}');

    buffer.writeln('${AppStrings.businessName}: ${customer.businessName}');

    buffer.writeln(

      '${AppStrings.businessCategory}: ${customer.businessCategory}',

    );

    buffer.writeln(

      '${AppStrings.marketingProblem}: ${customer.marketingProblem}',

    );

    buffer.writeln(

      '${AppStrings.providedService}: ${customer.providedService}',

    );

    if (customer.additionalNotes.trim().isNotEmpty) {

      buffer.writeln(

        '${AppStrings.additionalNotes}: ${customer.additionalNotes}',

      );

    }

    if (customer.employeeName != null &&

        customer.employeeName!.trim().isNotEmpty) {

      buffer.writeln(

        '${AppStrings.employeeName}: ${customer.employeeName}',

      );

    }

    buffer.writeln('---');

    buffer.writeln(

      '${AppStrings.createdAt}: ${dateFormat.format(customer.createdAt)} '

      '${timeFormat.format(customer.createdAt)}',

    );

    return buffer.toString().trim();

  }

}