import 'package:uuid/uuid.dart';

import '../models/customer_model.dart';

import '../models/activity_log_model.dart';

import 'hive_service.dart';

import 'activity_log_service.dart';

/// يحتوي كل منطق الأعمال المتعلق بالعملاء: الإضافة، التعديل، الحذف

/// الناعم، الاستعادة، الحذف النهائي، والبحث. هذه الطبقة هي المصدر

/// الوحيد الذي يُعدِّل صناديق العملاء مباشرة.

class CustomerService {

  CustomerService._();

  static const Uuid _uuid = Uuid();

  // ============ الإضافة ============

  /// يضيف عميلًا جديدًا، يولّد له معرّفًا فريدًا وتاريخ إنشاء تلقائيًا،

  /// ويسجّل النشاط في السجل.

  static Future<Customer> addCustomer({

    required String customerName,

    required String businessName,

    required String businessCategory,

    required String marketingProblem,

    required String providedService,

    required String additionalNotes,

    String? employeeName,

    required String performedBy,

  }) async {

    final DateTime now = DateTime.now();

    final Customer customer = Customer(

      id: _uuid.v4(),

      customerName: customerName,

      businessName: businessName,

      businessCategory: businessCategory,

      marketingProblem: marketingProblem,

      providedService: providedService,

      additionalNotes: additionalNotes,

      employeeName: employeeName,

      createdAt: now,

      lastModified: now,

    );

    await HiveService.customersBox.put(customer.id, customer);

    await ActivityLogService.logActivity(

      type: ActivityType.added,

      customerId: customer.id,

      customerName: customer.customerName,

      performedBy: performedBy,

    );

    return customer;

  }

  // ============ التعديل ============

  /// يحدّث بيانات عميل موجود عبر copyWith، ويحفظ النسخة الجديدة

  /// في نفس مكانها بالصندوق.

  static Future<void> updateCustomer({

    required Customer customer,

    required String performedBy,

    String? customerName,

    String? businessName,

    String? businessCategory,

    String? marketingProblem,

    String? providedService,

    String? additionalNotes,

    String? employeeName,

  }) async {

    final Customer updated = customer.copyWith(

      customerName: customerName,

      businessName: businessName,

      businessCategory: businessCategory,

      marketingProblem: marketingProblem,

      providedService: providedService,

      additionalNotes: additionalNotes,

      employeeName: employeeName,

    );

    await HiveService.customersBox.put(updated.id, updated);

    await ActivityLogService.logActivity(

      type: ActivityType.edited,

      customerId: updated.id,

      customerName: updated.customerName,

      performedBy: performedBy,

    );

  }

  // ============ الحذف الناعم ============

  /// ينقل عميلًا من صندوق العملاء النشطين إلى صندوق سلة المحذوفات.

  /// ننشئ نسخة منفصلة تمامًا من الكائن (وليس نفس المرجع) لأن Hive

  /// لا يسمح بربط نفس الكائن بصندوقين مختلفين في آنٍ واحد.

  static Future<void> softDeleteCustomer({

    required Customer customer,

    required String performedBy,

  }) async {

    final Customer detachedCopy = Customer(

      id: customer.id,

      customerName: customer.customerName,

      businessName: customer.businessName,

      businessCategory: customer.businessCategory,

      marketingProblem: customer.marketingProblem,

      providedService: customer.providedService,

      additionalNotes: customer.additionalNotes,

      employeeName: customer.employeeName,

      createdAt: customer.createdAt,

      lastModified: DateTime.now(),

      isFavorite: customer.isFavorite,

    );

    await HiveService.deletedCustomersBox.put(detachedCopy.id, detachedCopy);

    await HiveService.customersBox.delete(customer.id);

    await ActivityLogService.logActivity(

      type: ActivityType.deleted,

      customerId: customer.id,

      customerName: customer.customerName,

      performedBy: performedBy,

    );

  }

  // ============ الاستعادة ============

  /// يعيد عميلًا من سلة المحذوفات إلى قائمة العملاء النشطين.

  /// نفس مبدأ النسخة المنفصلة المستخدم في الحذف الناعم أعلاه.

  static Future<void> restoreCustomer({

    required Customer customer,

    required String performedBy,

  }) async {

    final Customer detachedCopy = Customer(

      id: customer.id,

      customerName: customer.customerName,

      businessName: customer.businessName,

      businessCategory: customer.businessCategory,

      marketingProblem: customer.marketingProblem,

      providedService: customer.providedService,

      additionalNotes: customer.additionalNotes,

      employeeName: customer.employeeName,

      createdAt: customer.createdAt,

      lastModified: DateTime.now(),

      isFavorite: customer.isFavorite,

    );

    await HiveService.customersBox.put(detachedCopy.id, detachedCopy);

    await HiveService.deletedCustomersBox.delete(customer.id);

    await ActivityLogService.logActivity(

      type: ActivityType.restored,

      customerId: customer.id,

      customerName: customer.customerName,

      performedBy: performedBy,

    );

  }

  // ============ الحذف النهائي ============

  /// يحذف عميلًا نهائيًا من سلة المحذوفات، بدون إمكانية تراجع.

  /// يُستخدم فقط من شاشة سلة المحذوفات بعد تأكيد صريح من المدير.

  static Future<void> permanentlyDeleteCustomer(String customerId) async {

    await HiveService.deletedCustomersBox.delete(customerId);

  }

  // ============ القراءة ============

  /// يعيد كل العملاء النشطين، الأحدث إضافة أولًا.

  static List<Customer> getAllCustomers() {

    final List<Customer> customers =

        HiveService.customersBox.values.toList();

    customers.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    return customers;

  }

  /// يعيد كل العملاء الموجودين حاليًا في سلة المحذوفات.

  static List<Customer> getDeletedCustomers() {

    final List<Customer> customers =

        HiveService.deletedCustomersBox.values.toList();

    customers.sort((a, b) => b.lastModified.compareTo(a.lastModified));

    return customers;

  }

  /// يعيد العملاء المفضّلين فقط من ضمن العملاء النشطين.

  static List<Customer> getFavoriteCustomers() {

    return getAllCustomers().where((c) => c.isFavorite).toList();

  }

  /// يبدّل حالة "مفضّل" لعميل معيّن.

  static Future<void> toggleFavorite(Customer customer) async {

    customer.isFavorite = !customer.isFavorite;

    await customer.save();

  }

  // ============ البحث ============

  /// يبحث في العملاء النشطين باسم العميل أو اسم النشاط التجاري.

  /// البحث محلي في الذاكرة، وهو كافٍ تمامًا لحجم بيانات لا يتجاوز

  /// بضع مئات من العملاء.

  static List<Customer> searchCustomers(String query) {

    if (query.trim().isEmpty) return getAllCustomers();

    final String normalizedQuery = query.trim().toLowerCase();

    return getAllCustomers().where((customer) {

      final String name = customer.customerName.toLowerCase();

      final String business = customer.businessName.toLowerCase();

      return name.contains(normalizedQuery) ||

          business.contains(normalizedQuery);

    }).toList();

  }

}