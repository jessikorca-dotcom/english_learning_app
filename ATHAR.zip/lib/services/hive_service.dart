import 'package:hive_flutter/hive_flutter.dart';

import '../core/constants/hive_constants.dart';

import '../models/customer_model.dart';

import '../models/activity_log_model.dart';

/// مسؤول عن تهيئة Hive بالكامل عند بدء تشغيل التطبيق:

/// تسجيل المحوّلات (Adapters)، وفتح كل الصناديق المطلوبة.

/// يجب استدعاء [initialize] مرة واحدة فقط قبل تشغيل التطبيق (في main.dart).

class HiveService {

  HiveService._();

  static bool _isInitialized = false;

  /// يهيّئ Hive ويفتح كل الصناديق. آمن للاستدعاء أكثر من مرة؛

  /// لن يُعيد التنفيذ إذا كان قد تمت التهيئة مسبقًا.

  static Future<void> initialize() async {

    if (_isInitialized) return;

    await Hive.initFlutter();

    _registerAdapters();

    await _openBoxes();

    _isInitialized = true;

  }

  /// يسجّل كل TypeAdapter يدوي كتبناه في طبقة models.

  /// كل نوع بيانات يجب أن يُسجَّل مرة واحدة فقط قبل فتح أي صندوق يستخدمه.

  static void _registerAdapters() {

    if (!Hive.isAdapterRegistered(HiveConstants.customerTypeId)) {

      Hive.registerAdapter(CustomerAdapter());

    }

    if (!Hive.isAdapterRegistered(HiveConstants.activityLogTypeId)) {

      Hive.registerAdapter(ActivityLogEntryAdapter());

    }

  }

  /// يفتح كل الصناديق المطلوبة بالتطبيق. الفتح يتم مرة واحدة فقط

  /// عند بدء التشغيل، وتبقى الصناديق مفتوحة طوال عمر التطبيق.

  static Future<void> _openBoxes() async {

    await Hive.openBox<Customer>(HiveConstants.customersBox);

    await Hive.openBox<Customer>(HiveConstants.deletedCustomersBox);

    await Hive.openBox<ActivityLogEntry>(HiveConstants.activityLogBox);

    await Hive.openBox(HiveConstants.settingsBox);

  }

  // ============ اختصارات للوصول المباشر للصناديق ============

  // بدل تكرار Hive.box<T>(name) في كل مكان بالتطبيق، نوفر وصولًا

  // مباشرًا وموثقًا هنا. هذه الصناديق تُستخدم من داخل طبقة

  // repositories فقط، ولا يجب أن تصل إليها الشاشات مباشرة.

  static Box<Customer> get customersBox =>

      Hive.box<Customer>(HiveConstants.customersBox);

  static Box<Customer> get deletedCustomersBox =>

      Hive.box<Customer>(HiveConstants.deletedCustomersBox);

  static Box<ActivityLogEntry> get activityLogBox =>

      Hive.box<ActivityLogEntry>(HiveConstants.activityLogBox);

  static Box get settingsBox => Hive.box(HiveConstants.settingsBox);

}