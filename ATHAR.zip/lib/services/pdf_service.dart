import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;

import 'package:pdf/pdf.dart';

import 'package:pdf/widgets.dart' as pw;

import 'package:printing/printing.dart';

import 'package:intl/intl.dart';

import '../core/constants/app_strings.dart';

import '../core/constants/app_constants.dart';

import '../core/utils/arabic_shaper.dart';

import '../models/customer_model.dart';

class PdfService {

  PdfService._();

  static String _shape(String text) => ArabicShaper.reshape(text);

  static Future<void> exportSingleCustomer(Customer customer) async {

    final pw.Font font = pw.Font.ttf(

      await rootBundle.load('assets/fonts/Cairo-Regular.ttf'),

    );

    final pw.Font boldFont = pw.Font.ttf(

      await rootBundle.load('assets/fonts/Cairo-Bold.ttf'),

    );

    final Uint8List logoBytes =

        (await rootBundle.load(AppConstants.companyLogoPath))

            .buffer

            .asUint8List();

    final pw.Document document = pw.Document();

    document.addPage(

      pw.Page(

        pageFormat: PdfPageFormat.a4,

        textDirection: pw.TextDirection.rtl,

        build: (context) {

          return pw.Directionality(

            textDirection: pw.TextDirection.rtl,

            child: pw.Column(

              crossAxisAlignment: pw.CrossAxisAlignment.stretch,

              children: [

                _buildHeader(boldFont, logoBytes),

                pw.SizedBox(height: 24),

                pw.Text(

                  _shape(AppStrings.customerDetails),

                  style: pw.TextStyle(font: boldFont, fontSize: 18),

                ),

                pw.Divider(),

                pw.SizedBox(height: 12),

                ..._buildCustomerFields(customer, font, boldFont),

              ],

            ),

          );

        },

      ),

    );

    await Printing.sharePdf(

      bytes: await document.save(),

      filename: '${customer.customerName}.pdf',

    );

  }

  static Future<void> exportAllCustomers(List<Customer> customers) async {

    final pw.Font font = pw.Font.ttf(

      await rootBundle.load('assets/fonts/Cairo-Regular.ttf'),

    );

    final pw.Font boldFont = pw.Font.ttf(

      await rootBundle.load('assets/fonts/Cairo-Bold.ttf'),

    );

    final Uint8List logoBytes =

        (await rootBundle.load(AppConstants.companyLogoPath))

            .buffer

            .asUint8List();

    final pw.Document document = pw.Document();

    for (final Customer customer in customers) {

      document.addPage(

        pw.Page(

          pageFormat: PdfPageFormat.a4,

          textDirection: pw.TextDirection.rtl,

          build: (context) {

            return pw.Directionality(

              textDirection: pw.TextDirection.rtl,

              child: pw.Column(

                crossAxisAlignment: pw.CrossAxisAlignment.stretch,

                children: [

                  _buildHeader(boldFont, logoBytes),

                  pw.SizedBox(height: 24),

                  ..._buildCustomerFields(customer, font, boldFont),

                ],

              ),

            );

          },

        ),

      );

    }

    await Printing.sharePdf(

      bytes: await document.save(),

      filename: 'كل_العملاء.pdf',

    );

  }

  static pw.Widget _buildHeader(pw.Font boldFont, Uint8List logoBytes) {

    return pw.Row(

      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,

      children: [

        pw.Text(

          _shape(AppStrings.appName),

          style: pw.TextStyle(font: boldFont, fontSize: 20),

        ),

        pw.Image(pw.MemoryImage(logoBytes), width: 50, height: 50),

      ],

    );

  }

  static List<pw.Widget> _buildCustomerFields(

    Customer customer,

    pw.Font font,

    pw.Font boldFont,

  ) {

    final DateFormat dateFormat = DateFormat(AppConstants.dateFormatPattern);

    final DateFormat timeFormat = DateFormat(AppConstants.timeFormatPattern);

    final List<MapEntry<String, String>> fields = [

      MapEntry(AppStrings.customerName, customer.customerName),

      MapEntry(AppStrings.businessName, customer.businessName),

      MapEntry(AppStrings.businessCategory, customer.businessCategory),

      MapEntry(AppStrings.marketingProblem, customer.marketingProblem),

      MapEntry(AppStrings.providedService, customer.providedService),

      if (customer.additionalNotes.trim().isNotEmpty)

        MapEntry(AppStrings.additionalNotes, customer.additionalNotes),

      if (customer.employeeName != null &&

          customer.employeeName!.trim().isNotEmpty)

        MapEntry(AppStrings.employeeName, customer.employeeName!),

      MapEntry(

        AppStrings.createdAt,

        '${dateFormat.format(customer.createdAt)} '

        '${timeFormat.format(customer.createdAt)}',

      ),

    ];

    return fields

        .map(

          (entry) => pw.Padding(

            padding: const pw.EdgeInsets.symmetric(vertical: 6),

            child: pw.Column(

              crossAxisAlignment: pw.CrossAxisAlignment.stretch,

              children: [

                pw.Text(

                  _shape(entry.key),

                  style: pw.TextStyle(

                    font: boldFont,

                    fontSize: 12,

                    color: PdfColors.grey700,

                  ),

                ),

                pw.SizedBox(height: 2),

                pw.Text(

                  _shape(entry.value),

                  style: pw.TextStyle(font: font, fontSize: 14),

                ),

              ],

            ),

          ),

        )

        .toList();

  }

}